"""
session_manager.py — Per-user session state manager.
Tracks workflow state across Streamlit reruns within a session.
Prevents duplicate submissions, manages cooldown windows, persists audit trail.
"""
from __future__ import annotations
import json
import logging
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from enum import Enum
from pathlib import Path

logger = logging.getLogger(__name__)


class WorkflowStage(str, Enum):
    IDLE              = "IDLE"
    FETCHING_LOG      = "FETCHING_LOG"
    DEDUP_CHECK       = "DEDUP_CHECK"
    DIAGNOSING        = "DIAGNOSING"
    AWAITING_USER_FIX = "AWAITING_USER_FIX"   # HITL Gate 1
    RERUNNING         = "RERUNNING"
    GENERATING_TEMPLATE = "GENERATING_TEMPLATE"
    AWAITING_SUBMIT   = "AWAITING_SUBMIT"      # HITL Gate 2
    CREATING_TICKET   = "CREATING_TICKET"
    COMPLETE          = "COMPLETE"
    ERROR             = "ERROR"


@dataclass
class SessionState:
    user_id:         str
    machine_id:      str
    run_id:          str
    stage:           WorkflowStage = WorkflowStage.IDLE
    error_hash:      str = ""
    bot_version:     str = ""

    # Dedup
    dedup_scenario:  str = ""
    existing_ticket: str = ""

    # Diagnostic
    decision:        str = ""
    confidence_band: str = ""
    plain_english_fix: str = ""
    rerun_safe:      bool = False

    # Rerun
    rerun_attempted: bool = False
    rerun_success:   bool = False
    rerun_timestamp: str = ""

    # Template
    template_generated: bool = False
    user_comments:   str = ""

    # Final ticket
    jira_ticket_key: str = ""
    jira_ticket_url: str = ""

    # Audit
    started_at:      str = ""
    completed_at:    str = ""
    audit_trail:     list = field(default_factory=list)

    def __post_init__(self):
        if not self.started_at:
            self.started_at = datetime.now(timezone.utc).isoformat()

    def advance(self, new_stage: WorkflowStage, note: str = ""):
        """Move to next stage and log audit entry."""
        self.stage = new_stage
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "stage":     new_stage.value,
            "note":      note,
        }
        self.audit_trail.append(entry)
        logger.info(f"Session {self.run_id} → {new_stage.value}" + (f" | {note}" if note else ""))

    def is_within_cooldown(self) -> bool:
        """
        Prevent duplicate reruns within cooldown window.
        Returns True if a rerun was attempted recently.
        """
        if not self.rerun_timestamp:
            return False
        from config import cfg
        last = datetime.fromisoformat(self.rerun_timestamp)
        cooldown = timedelta(minutes=cfg.rerun_cooldown_minutes)
        return datetime.now(timezone.utc) - last < cooldown

    def mark_complete(self):
        self.completed_at = datetime.now(timezone.utc).isoformat()
        self.advance(WorkflowStage.COMPLETE, f"Ticket: {self.jira_ticket_key}")

    def to_dict(self) -> dict:
        d = asdict(self)
        d["stage"] = self.stage.value
        return d


# ── In-memory store (per Streamlit session via st.session_state) ──────────
# For production: replace with Redis or Azure Table Storage

_SESSIONS: dict[str, SessionState] = {}


def get_or_create(
    user_id: str,
    machine_id: str,
    run_id: str,
) -> SessionState:
    """
    Get existing session for this run_id, or create a new one.
    Same run_id = same session (prevents duplicate processing).
    """
    key = f"{user_id}:{run_id}"
    if key not in _SESSIONS:
        _SESSIONS[key] = SessionState(
            user_id=user_id,
            machine_id=machine_id,
            run_id=run_id,
        )
        logger.info(f"New session created: {key}")
    else:
        logger.info(f"Existing session resumed: {key}")
    return _SESSIONS[key]


def get(user_id: str, run_id: str) -> SessionState | None:
    return _SESSIONS.get(f"{user_id}:{run_id}")


def save_audit(session: SessionState, audit_path: str = "./audit_logs"):
    """Persist session audit trail to JSON file for compliance."""
    Path(audit_path).mkdir(parents=True, exist_ok=True)
    filename = f"{audit_path}/{session.run_id}_{session.user_id}.json"
    with open(filename, "w") as f:
        json.dump(session.to_dict(), f, indent=2)
    logger.info(f"Audit trail saved: {filename}")
