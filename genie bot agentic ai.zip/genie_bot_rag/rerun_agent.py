"""
rerun_agent.py — Agent 4: Controlled Rerun Agent
Triggers a safe, single-attempt rerun of the Genie Bot batch file.
Only runs if diagnostic.rerun_safe = True.
Max 1 attempt. Monitors exit code. Returns outcome.
"""
from __future__ import annotations
import logging
import subprocess
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from config import cfg

logger = logging.getLogger(__name__)

RERUN_TIMEOUT_SECONDS = 300   # 5 min max — adjust to your bot's typical run time
MAX_RERUN_ATTEMPTS    = 1     # Never more than 1 automated rerun


@dataclass
class RerunResult:
    attempted:     bool
    success:       bool
    exit_code:     int
    stdout:        str
    stderr:        str
    duration_secs: float
    error_message: str = ""
    timestamp:     str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    @property
    def user_message(self) -> str:
        if not self.attempted:
            return "Re-run was not attempted — this issue requires specialist support."
        if self.success:
            return (
                "Great news! The bot has re-run successfully after applying the fix. "
                "Your report should be available shortly."
            )
        return (
            "The bot was restarted but encountered the same issue again. "
            "Don't worry — we are raising this with the specialist support team now."
        )


def _find_batch_file(bot_install_path: str) -> Path | None:
    """Locate the Genie Bot batch (.bat) file in the install directory."""
    install = Path(bot_install_path)
    bat_files = list(install.glob("*.bat"))
    if not bat_files:
        logger.error(f"No .bat file found in {bot_install_path}")
        return None
    # Prefer 'run.bat' or 'start.bat' if multiple exist
    for preferred in ("run.bat", "start.bat", "GenieBot.bat"):
        match = install / preferred
        if match.exists():
            return match
    return bat_files[0]


def attempt_rerun(
    bot_install_path: str,
    run_id: str,
    rerun_safe: bool,
) -> RerunResult:
    """
    Attempt a controlled single rerun of the Genie Bot batch file.

    Safety checks:
    - rerun_safe must be True (set by Diagnostic Agent)
    - Only 1 attempt ever
    - Timeout enforced
    - Subprocess run — no admin privileges required
    """
    if not rerun_safe:
        logger.info("Rerun skipped — diagnostic flagged rerun_safe=False")
        return RerunResult(
            attempted=False, success=False, exit_code=-1,
            stdout="", stderr="",
            duration_secs=0,
            error_message="Rerun not safe for this error type.",
        )

    batch_file = _find_batch_file(bot_install_path)
    if not batch_file:
        return RerunResult(
            attempted=False, success=False, exit_code=-1,
            stdout="", stderr="",
            duration_secs=0,
            error_message=f"Batch file not found in {bot_install_path}",
        )

    logger.info(f"Initiating controlled rerun | batch={batch_file} | run_id={run_id}")
    start = time.time()

    try:
        proc = subprocess.run(
            [str(batch_file)],
            capture_output=True,
            text=True,
            timeout=RERUN_TIMEOUT_SECONDS,
            cwd=str(batch_file.parent),
        )
        duration = round(time.time() - start, 2)
        success  = proc.returncode == 0

        logger.info(
            f"Rerun complete | exit_code={proc.returncode} | "
            f"success={success} | duration={duration}s"
        )
        return RerunResult(
            attempted=True,
            success=success,
            exit_code=proc.returncode,
            stdout=proc.stdout[:2000],
            stderr=proc.stderr[:2000],
            duration_secs=duration,
        )

    except subprocess.TimeoutExpired:
        duration = round(time.time() - start, 2)
        logger.error(f"Rerun timed out after {RERUN_TIMEOUT_SECONDS}s")
        return RerunResult(
            attempted=True, success=False, exit_code=-1,
            stdout="", stderr="",
            duration_secs=duration,
            error_message=f"Rerun timed out after {RERUN_TIMEOUT_SECONDS} seconds.",
        )
    except Exception as e:
        duration = round(time.time() - start, 2)
        logger.error(f"Rerun failed with exception: {e}")
        return RerunResult(
            attempted=True, success=False, exit_code=-1,
            stdout="", stderr="",
            duration_secs=duration,
            error_message=str(e),
        )
