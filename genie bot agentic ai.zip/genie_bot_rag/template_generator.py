"""
template_generator.py — Agent 5: Template Generator
Pre-fills L2 escalation template including L1 attempt record.
Shown in Streamlit for HITL Gate 2 — user reviews before submit.
"""
from __future__ import annotations
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone

from langchain_openai import AzureChatOpenAI
from langchain.prompts import ChatPromptTemplate

from config import cfg
from masking import mask_document
from retriever import DiagnosticResult
from rerun_agent import RerunResult

logger = logging.getLogger(__name__)


@dataclass
class EscalationTemplate:
    # Auto-filled fields
    run_id:                str
    bot_version:           str
    error_summary:         str
    error_classification:  str
    affected_module:       str
    priority:              str
    stack_trace_summary:   str
    sop_reference:         str
    confidence_band:       str
    similar_ticket_ids:    list = field(default_factory=list)
    link_to_ticket:        str = ""

    # L1 attempt record — critical for L2 context
    l1_fix_suggested:      str = ""
    l1_fix_attempted:      bool = False
    rerun_attempted:       bool = False
    rerun_outcome:         str = ""   # "SUCCESS" | "FAILED" | "TIMEOUT" | "NOT_ATTEMPTED"
    rerun_exit_code:       int = -1
    escalation_reason:     str = ""  # NO_MATCH | LOW_CONFIDENCE | L1_FAILED | RERUN_UNSAFE

    # User-editable fields (filled in Streamlit)
    user_additional_comments: str = ""

    # Metadata
    timestamp:             str = ""
    submitted_by:          str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")


TEMPLATE_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are an L2 escalation template agent for Genie Bot support.
Extract and structure key fields from the provided error information.
Output ONLY valid JSON — no markdown, no preamble.

Schema:
{{
  "error_summary": "One-line summary of the error in plain English",
  "error_classification": "NullReference | Timeout | Config | Connectivity | Data | Auth | Unknown",
  "affected_module": "Which Genie Bot module failed",
  "priority": "High | Medium | Low",
  "stack_trace_summary": "2-3 sentence plain English description of what failed and where",
  "sop_reference": "Matching SOP reference if found, else 'Novel issue — no SOP match'"
}}"""),

    ("human", """MASKED LOG SUMMARY:
Error Code: {error_code}
Module: {module}
Bot Version: {bot_version}
Stack Summary: {stack_summary}

DIAGNOSTIC RESULT:
Decision: {decision}
SOP Summary: {sop_summary}
Confidence: {confidence_band}
Escalation Reason: {escalation_reason}

L1 FIX ATTEMPTED: {l1_attempted}
RERUN OUTCOME: {rerun_outcome}

Generate pre-filled template JSON now.""")
])


def _get_llm() -> AzureChatOpenAI:
    return AzureChatOpenAI(
        azure_deployment=cfg.llm_deployment,
        azure_endpoint=cfg.azure_openai_endpoint,
        api_key=cfg.azure_openai_api_key,
        api_version=cfg.azure_openai_api_version,
        temperature=0.0,
        max_tokens=600,
    )


def _determine_escalation_reason(
    diagnostic: DiagnosticResult,
    rerun_result: RerunResult | None,
) -> str:
    if diagnostic.top_score < cfg.similarity_threshold:
        return "NO_MATCH"
    elif diagnostic.confidence_band == "MEDIUM":
        return "LOW_CONFIDENCE"
    elif rerun_result and rerun_result.attempted and not rerun_result.success:
        return "L1_FAILED"
    elif not diagnostic.rerun_safe:
        return "RERUN_UNSAFE"
    return "UNKNOWN"


def generate(
    diagnostic: DiagnosticResult,
    rerun_result: RerunResult | None = None,
    link_to_ticket: str = "",
    user_id: str = "UNKNOWN",
) -> EscalationTemplate:
    """
    Generate pre-filled L2 escalation template.
    Records L1 attempt details so L2 team has full context.
    """
    pl = diagnostic.parsed_log
    escalation_reason = _determine_escalation_reason(diagnostic, rerun_result)

    l1_attempted = rerun_result is not None and rerun_result.attempted
    rerun_outcome = "NOT_ATTEMPTED"
    if rerun_result:
        if rerun_result.success:
            rerun_outcome = "SUCCESS"
        elif rerun_result.error_message and "timed out" in rerun_result.error_message:
            rerun_outcome = "TIMEOUT"
        elif rerun_result.attempted:
            rerun_outcome = "FAILED"
        else:
            rerun_outcome = "NOT_ATTEMPTED"

    similar_tickets = [
        m.metadata.get("ticket_id", "")
        for m in diagnostic.matches
        if m.is_match and m.metadata.get("ticket_id")
    ]

    # LLM-generated fields
    llm = _get_llm()
    prompt = TEMPLATE_PROMPT.format_messages(
        error_code=pl.error_code,
        module=pl.module,
        bot_version=pl.bot_version,
        stack_summary=pl.stack_summary[:600],
        decision=diagnostic.decision,
        sop_summary=diagnostic.sop_summary,
        confidence_band=diagnostic.confidence_band,
        escalation_reason=escalation_reason,
        l1_attempted=str(l1_attempted),
        rerun_outcome=rerun_outcome,
    )

    logger.info("Generating L2 escalation template...")
    response = llm.invoke(prompt)
    raw = response.content.strip()

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("Template LLM not valid JSON — using fallback values")
        parsed = {
            "error_summary":      f"{pl.error_code} in {pl.module}",
            "error_classification": "Unknown",
            "affected_module":    pl.module,
            "priority":           "Medium",
            "stack_trace_summary": pl.stack_summary[:300],
            "sop_reference":      "No SOP match found — novel issue",
        }

    return EscalationTemplate(
        run_id=pl.run_id,
        bot_version=pl.bot_version,
        error_summary=parsed.get("error_summary", ""),
        error_classification=parsed.get("error_classification", "Unknown"),
        affected_module=parsed.get("affected_module", pl.module),
        priority=parsed.get("priority", "Medium"),
        stack_trace_summary=parsed.get("stack_trace_summary", ""),
        sop_reference=parsed.get("sop_reference", ""),
        confidence_band=diagnostic.confidence_band,
        similar_ticket_ids=similar_tickets,
        link_to_ticket=link_to_ticket,
        l1_fix_suggested=diagnostic.plain_english_fix,
        l1_fix_attempted=l1_attempted,
        rerun_attempted=rerun_result.attempted if rerun_result else False,
        rerun_outcome=rerun_outcome,
        rerun_exit_code=rerun_result.exit_code if rerun_result else -1,
        escalation_reason=escalation_reason,
        submitted_by=user_id,
    )
