# Genie Bot Agentic AI Copilot

## Module Map

```
genie_bot_rag/
├── config.py              # All settings — env vars, thresholds, model names
├── masking.py             # PII redaction + error fingerprint hash
├── s3_agent.py            # Agent 1: Fetch & parse S3 logs
├── dedup_agent.py         # Agent 2: Jira deduplication — 5 scenarios
├── retriever.py           # Agent 3: RAG diagnosis (FAISS + GPT-4.1)
├── rerun_agent.py         # Agent 4: Controlled batch file rerun
├── template_generator.py  # Agent 5: Pre-fill L2 escalation template
├── jira_agent.py          # Agent 6: Create/update Jira tickets
├── session_manager.py     # Per-user workflow state + audit trail
├── ingestor.py            # Data ingestion → FAISS index builder
├── pipeline.py            # Orchestrator — 3 stages + CLI
├── app.py                 # Streamlit UI (10 panels)
├── .env.example           # Environment variable template
└── requirements.txt
```

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# Fill in .env with your Azure/Jira/AWS credentials
```

## Step 1 — Ingest data (once)
```bash
python pipeline.py ingest --data ./data
# data/ should contain: jira/*.csv  logs/*.log  sop/*.md
```

## Step 2 — Run Streamlit app
```bash
streamlit run app.py
```

## Step 3 — CLI test
```bash
python pipeline.py diagnose --log ./data/logs/test.log --run-id GBT-001
```

## Deduplication Scenarios

| # | Situation | Action |
|---|---|---|
| 1 | No existing ticket | Full diagnosis flow |
| 2 | Same user, same run | Block — show existing ticket |
| 3 | Same user, recurring | Show ticket + offer to add comment |
| 4 | Different user, same error | Link + add as affected user |
| 5 | Similar error | Soft-link, raise new ticket |

## Workflow Stages

```
IDLE → DIAGNOSING → DEDUP_CHECK
                  ↓
            [Dedup blocked] → DEDUP_BLOCKED
                  ↓
            [New issue] → AWAITING_USER_FIX (HITL Gate 1)
                               ↓
                          RERUNNING
                          ↓         ↓
                       SUCCESS    FAILED
                          ↓         ↓
                    RESOLVED   AWAITING_SUBMIT (HITL Gate 2)
                                    ↓
                               ESCALATED
```
