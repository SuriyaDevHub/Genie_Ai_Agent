"""
s3_agent.py — Agent 1: Log Parser Agent
Fetches Genie Bot execution logs from AWS S3, applies masking,
extracts structured diagnostic payload and error fingerprint.
"""
from __future__ import annotations
import io
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

import boto3
from botocore.exceptions import ClientError, NoCredentialsError

from config import cfg
from masking import mask_document, compute_error_hash

logger = logging.getLogger(__name__)


@dataclass
class ParsedLog:
    run_id:         str
    user_id:        str
    machine_id:     str
    timestamp:      str
    bot_version:    str
    module:         str
    error_code:     str
    line_ref:       str
    exit_status:    str
    stack_summary:  str
    raw_masked:     str
    error_hash:     str
    s3_path:        str
    fetch_error:    str = ""

    @property
    def is_valid(self) -> bool:
        return not self.fetch_error and bool(self.error_code)


def _get_s3_client():
    if cfg.aws_access_key_id:
        return boto3.client(
            "s3",
            aws_access_key_id=cfg.aws_access_key_id,
            aws_secret_access_key=cfg.aws_secret_access_key,
            region_name=cfg.aws_region,
        )
    # Fall back to IAM role (preferred in production)
    return boto3.client("s3", region_name=cfg.aws_region)


def _build_s3_key(run_id: str, timestamp: str) -> str:
    """
    Construct S3 key from run_id and timestamp.
    Convention: {prefix}{YYYY}/{MM}/{DD}/{run_id}.log
    """
    try:
        dt = datetime.fromisoformat(timestamp)
    except Exception:
        dt = datetime.now(timezone.utc)
    return (
        f"{cfg.s3_log_prefix}"
        f"{dt.year}/{dt.month:02d}/{dt.day:02d}/"
        f"{run_id}.log"
    )


def _extract_fields(raw_text: str) -> dict:
    """
    Parse key fields from raw log text using regex patterns.
    Designed for Genie Bot's standard log format.
    Falls back gracefully if fields are missing.
    """
    def find(pattern, default="UNKNOWN"):
        m = re.search(pattern, raw_text, re.IGNORECASE | re.MULTILINE)
        return m.group(1).strip() if m else default

    error_code  = find(r"(?:System\.)?(\w+Exception|\w+Error)(?:\s*:)")
    module      = find(r"Module\s*:\s*(\S+)")
    line_ref    = find(r"at\s+\S+\s+in\s+(\S+\.cs:\w+\s+\d+)")
    exit_status = find(r"Exit(?:Status)?\s*:\s*(FAILED|SUCCESS|PARTIAL|ERROR)")
    bot_version = find(r"(?:Version|BotVersion)\s*[=:]\s*([\d.]+)")
    user_id     = find(r"(?:User|UserId)\s*[=:]\s*(\S+)")
    machine_id  = find(r"(?:Machine|Host|MachineName)\s*[=:]\s*(\S+)")

    # Stack summary — first 5 lines of stack trace
    stack_lines = re.findall(r"^\s+at\s+.+$", raw_text, re.MULTILINE)
    stack_summary = "\n".join(stack_lines[:5]) if stack_lines else raw_text[:400]

    return {
        "error_code":   error_code,
        "module":       module,
        "line_ref":     line_ref,
        "exit_status":  exit_status,
        "bot_version":  bot_version,
        "user_id":      user_id,
        "machine_id":   machine_id,
        "stack_summary": stack_summary,
    }


def fetch_and_parse(
    run_id: str,
    timestamp: str,
    user_id: str = "UNKNOWN",
    machine_id: str = "UNKNOWN",
    local_log_text: str = None,   # For ideation/testing — inject log directly
) -> ParsedLog:
    """
    Main entry point for Log Parser Agent.
    1. Fetch log from S3 (or use injected text for testing)
    2. Mask PII/financial identifiers
    3. Extract structured fields
    4. Compute error fingerprint hash
    """
    s3_path = _build_s3_key(run_id, timestamp)
    raw_text = ""

    if local_log_text:
        # Testing / ideation mode — bypass S3
        logger.info(f"Using injected log text for run_id={run_id}")
        raw_text = local_log_text
    else:
        try:
            logger.info(f"Fetching S3 log: s3://{cfg.s3_bucket_name}/{s3_path}")
            s3 = _get_s3_client()
            obj = s3.get_object(Bucket=cfg.s3_bucket_name, Key=s3_path)
            raw_text = obj["Body"].read().decode("utf-8", errors="replace")
            logger.info(f"S3 fetch successful — {len(raw_text)} chars")
        except ClientError as e:
            err = f"S3 fetch failed: {e.response['Error']['Code']} — {s3_path}"
            logger.error(err)
            return ParsedLog(
                run_id=run_id, user_id=user_id, machine_id=machine_id,
                timestamp=timestamp, bot_version="UNKNOWN", module="UNKNOWN",
                error_code="UNKNOWN", line_ref="UNKNOWN", exit_status="FAILED",
                stack_summary="", raw_masked="", error_hash="",
                s3_path=s3_path, fetch_error=err,
            )
        except NoCredentialsError:
            err = "AWS credentials not configured. Set AWS_ACCESS_KEY_ID or use IAM role."
            logger.error(err)
            return ParsedLog(
                run_id=run_id, user_id=user_id, machine_id=machine_id,
                timestamp=timestamp, bot_version="UNKNOWN", module="UNKNOWN",
                error_code="UNKNOWN", line_ref="UNKNOWN", exit_status="FAILED",
                stack_summary="", raw_masked="", error_hash="",
                s3_path=s3_path, fetch_error=err,
            )

    # Mask before any further processing
    masked_text = mask_document(raw_text)
    fields = _extract_fields(raw_text)  # Extract from raw (masking happens after)

    error_hash = compute_error_hash(
        fields["error_code"],
        fields["module"],
        fields["line_ref"],
    )

    logger.info(
        f"Log parsed | error={fields['error_code']} | "
        f"module={fields['module']} | hash={error_hash}"
    )

    return ParsedLog(
        run_id=run_id,
        user_id=fields.get("user_id", user_id),
        machine_id=fields.get("machine_id", machine_id),
        timestamp=timestamp,
        bot_version=fields["bot_version"],
        module=fields["module"],
        error_code=fields["error_code"],
        line_ref=fields["line_ref"],
        exit_status=fields["exit_status"],
        stack_summary=mask_document(fields["stack_summary"]),
        raw_masked=masked_text,
        error_hash=error_hash,
        s3_path=s3_path,
    )
