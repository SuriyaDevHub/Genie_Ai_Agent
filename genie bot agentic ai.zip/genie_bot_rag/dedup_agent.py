"""
dedup_agent.py — Agent 2: Deduplication Agent
Checks Jira for existing open tickets before diagnosis.
Handles all 5 deduplication scenarios:
  1. No existing ticket     → proceed normally
  2. Same user, same run    → block (already raised)
  3. Same user, new run     → prompt (recurring issue)
  4. Different user, same   → link + notify
  5. Similar issue          → soft-link, new ticket
"""
from __future__ import annotations
import logging
from dataclasses import dataclass
from enum import Enum
from typing import Optional

import requests
from requests.auth import HTTPBasicAuth

from config import cfg
from s3_agent import ParsedLog

logger = logging.getLogger(__name__)


class DedupScenario(str, Enum):
    NEW_ISSUE           = "NEW_ISSUE"
    DUPLICATE_SAME_RUN  = "DUPLICATE_SAME_RUN"
    RECURRING_SAME_USER = "RECURRING_SAME_USER"
    SAME_ISSUE_DIFF_USER= "SAME_ISSUE_DIFF_USER"
    SIMILAR_ISSUE       = "SIMILAR_ISSUE"


@dataclass
class DedupResult:
    scenario:         DedupScenario
    existing_ticket:  Optional[str]    = None   # e.g. "GBOT-1042"
    existing_summary: Optional[str]    = None
    existing_status:  Optional[str]    = None
    affected_users:   list             = None
    user_message:     str              = ""
    proceed_to_diag:  bool             = True    # False = block further processing
    link_to_ticket:   Optional[str]    = None    # Ticket to link new one to

    def __post_init__(self):
        if self.affected_users is None:
            self.affected_users = []


def _jira_auth() -> HTTPBasicAuth:
    return HTTPBasicAuth(cfg.jira_user_email, cfg.jira_api_token)


def _jira_headers() -> dict:
    return {"Accept": "application/json", "Content-Type": "application/json"}


def _search_jira_by_hash(error_hash: str) -> list[dict]:
    """Search Jira for open tickets with matching error_hash custom field."""
    jql = (
        f'project = {cfg.jira_project_key} '
        f'AND status in ("Open","To Do","In Progress") '
        f'AND "Error Hash" ~ "{error_hash}"'
    )
    try:
        resp = requests.get(
            f"{cfg.jira_base_url}/rest/api/3/search",
            auth=_jira_auth(),
            headers=_jira_headers(),
            params={"jql": jql, "maxResults": 10,
                    "fields": "summary,status,reporter,customfield_error_hash,customfield_affected_users,customfield_run_id"},
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json().get("issues", [])
    except Exception as e:
        logger.warning(f"Jira dedup search failed: {e}")
        return []


def _add_affected_user(ticket_key: str, user_id: str, run_id: str) -> bool:
    """Append user_id to the Affected Users field and add a comment."""
    comment = {
        "body": {
            "type": "doc", "version": 1,
            "content": [{"type": "paragraph", "content": [
                {"type": "text",
                 "text": f"Additional user affected: {user_id} | Run ID: {run_id}"}
            ]}]
        }
    }
    try:
        resp = requests.post(
            f"{cfg.jira_base_url}/rest/api/3/issue/{ticket_key}/comment",
            auth=_jira_auth(),
            headers=_jira_headers(),
            json=comment,
            timeout=10,
        )
        resp.raise_for_status()
        logger.info(f"Added affected user {user_id} to {ticket_key}")

        # Auto-escalate priority if multi-user threshold reached
        _check_priority_escalation(ticket_key)
        return True
    except Exception as e:
        logger.error(f"Failed to add affected user to {ticket_key}: {e}")
        return False


def _check_priority_escalation(ticket_key: str):
    """
    If affected user count >= threshold, auto-escalate priority to High.
    Signals systemic issue, not user-specific.
    """
    try:
        resp = requests.get(
            f"{cfg.jira_base_url}/rest/api/3/issue/{ticket_key}",
            auth=_jira_auth(), headers=_jira_headers(), timeout=10,
        )
        resp.raise_for_status()
        issue = resp.json()
        comments = issue.get("fields", {}).get("comment", {}).get("total", 0)

        # Approximate affected count from comments (each new user adds a comment)
        if comments >= cfg.multi_user_priority_threshold:
            requests.put(
                f"{cfg.jira_base_url}/rest/api/3/issue/{ticket_key}",
                auth=_jira_auth(), headers=_jira_headers(),
                json={"fields": {"priority": {"name": "High"}}},
                timeout=10,
            )
            logger.warning(
                f"Priority escalated to High on {ticket_key} — "
                f"{comments} users affected"
            )
    except Exception as e:
        logger.warning(f"Priority escalation check failed: {e}")


def check(parsed_log: ParsedLog) -> DedupResult:
    """
    Main deduplication check. Run this BEFORE Diagnostic Agent.
    Returns DedupResult with scenario + user message + routing decision.
    """
    if not parsed_log.is_valid:
        # Can't deduplicate without a valid error hash
        return DedupResult(
            scenario=DedupScenario.NEW_ISSUE,
            user_message="",
            proceed_to_diag=True,
        )

    existing = _search_jira_by_hash(parsed_log.error_hash)

    if not existing:
        logger.info(f"No existing ticket for hash={parsed_log.error_hash} → NEW_ISSUE")
        return DedupResult(
            scenario=DedupScenario.NEW_ISSUE,
            user_message="",
            proceed_to_diag=True,
        )

    ticket   = existing[0]
    t_key    = ticket["key"]
    t_sum    = ticket["fields"]["summary"]
    t_status = ticket["fields"]["status"]["name"]
    t_run_id = ticket["fields"].get("customfield_run_id", "")
    t_reporter = ticket["fields"].get("reporter", {}).get("emailAddress", "")

    logger.info(f"Existing ticket found: {t_key} | status={t_status}")

    # ── Scenario 2: Same user, same run ──────────────────────────────
    if t_run_id == parsed_log.run_id and t_reporter == parsed_log.user_id:
        return DedupResult(
            scenario=DedupScenario.DUPLICATE_SAME_RUN,
            existing_ticket=t_key,
            existing_summary=t_sum,
            existing_status=t_status,
            proceed_to_diag=False,
            user_message=(
                f"You've already reported this issue. Your support ticket "
                f"**{t_key}** is currently **{t_status}** and the support team "
                f"is working on it. No further action is needed from you."
            ),
        )

    # ── Scenario 3: Same user, different run (recurring) ─────────────
    if t_reporter == parsed_log.user_id:
        _add_affected_user(t_key, parsed_log.user_id, parsed_log.run_id)
        return DedupResult(
            scenario=DedupScenario.RECURRING_SAME_USER,
            existing_ticket=t_key,
            existing_summary=t_sum,
            existing_status=t_status,
            proceed_to_diag=False,
            user_message=(
                f"This bot has failed with the same issue again. "
                f"Your existing ticket **{t_key}** is still **{t_status}**. "
                f"The support team has been notified that the issue is recurring. "
                f"Would you like to add a note to help the team?"
            ),
        )

    # ── Scenario 4: Different user, same error ────────────────────────
    if t_reporter != parsed_log.user_id:
        _add_affected_user(t_key, parsed_log.user_id, parsed_log.run_id)
        return DedupResult(
            scenario=DedupScenario.SAME_ISSUE_DIFF_USER,
            existing_ticket=t_key,
            existing_summary=t_sum,
            existing_status=t_status,
            affected_users=[t_reporter, parsed_log.user_id],
            proceed_to_diag=False,
            user_message=(
                f"Another team member has already reported this exact issue. "
                f"It is being investigated under ticket **{t_key}** "
                f"(currently **{t_status}**). "
                f"You've been added as an affected user — the support team will "
                f"keep you updated when it is resolved."
            ),
        )

    # ── Scenario 5: Similar but not identical (fallback) ─────────────
    return DedupResult(
        scenario=DedupScenario.SIMILAR_ISSUE,
        existing_ticket=t_key,
        existing_summary=t_sum,
        existing_status=t_status,
        proceed_to_diag=True,
        link_to_ticket=t_key,
        user_message=(
            f"We found a similar known issue (**{t_key}**) but your error has "
            f"some differences. We are raising a new ticket and linking it for "
            f"the support team to review together."
        ),
    )
