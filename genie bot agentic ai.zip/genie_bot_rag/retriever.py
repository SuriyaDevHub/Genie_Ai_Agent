"""
retriever.py — Agent 3: Diagnostic Agent (L1 Triage)
Semantic search against FAISS + GPT-4.1 SOP mapping.
Produces plain-English output for non-IT business users.
"""
from __future__ import annotations
import json
import logging
from dataclasses import dataclass, field
from typing import Optional

from langchain_openai import AzureChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain_community.vectorstores import FAISS

from config import cfg
from masking import mask_document
from s3_agent import ParsedLog

logger = logging.getLogger(__name__)


@dataclass
class RetrievedMatch:
    content:   str
    score:     float
    metadata:  dict
    is_match:  bool


@dataclass
class DiagnosticResult:
    parsed_log:          ParsedLog
    matches:             list = field(default_factory=list)
    top_score:           float = 0.0
    decision:            str  = "ESCALATE"   # AUTO_RESOLVE | ESCALATE | UNKNOWN
    confidence_band:     str  = "LOW"        # HIGH | MEDIUM | LOW
    sop_summary:         str  = ""
    plain_english_fix:   str  = ""           # Non-IT user friendly explanation
    suggested_fix:       str  = ""           # Technical steps
    rerun_safe:          bool = False
    reasoning:           str  = ""
    raw_llm_response:    str  = ""


def _get_llm() -> AzureChatOpenAI:
    return AzureChatOpenAI(
        azure_deployment=cfg.llm_deployment,
        azure_endpoint=cfg.azure_openai_endpoint,
        api_key=cfg.azure_openai_api_key,
        api_version=cfg.azure_openai_api_version,
        temperature=cfg.llm_temperature,
        max_tokens=cfg.llm_max_tokens,
    )


DIAGNOSTIC_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are a deterministic L1 triage agent for Genie Bot production support.

STRICT RULES:
- Temperature=0. Never improvise. Only use information from the retrieved historical incidents.
- If unsure, always choose ESCALATE — safer than wrong auto-resolve.
- plain_english_fix must be written for a non-technical business user.
  Use simple language. No stack traces. No code. No jargon.
  Example: "The bot could not find the report settings for your team.
  Please click Try Fix & Re-run to apply the latest settings and restart."
- rerun_safe=true ONLY if the historical fix involved a simple config/setting change.
  Never true if the fix involved database changes, file deletions, or manual admin steps.

Output ONLY valid JSON — no markdown, no preamble:
{{
  "decision": "AUTO_RESOLVE" or "ESCALATE" or "UNKNOWN",
  "confidence_band": "HIGH" or "MEDIUM" or "LOW",
  "sop_summary": "Technical one-line SOP reference",
  "plain_english_fix": "Simple plain English explanation for a non-technical business user",
  "suggested_fix": "Technical step-by-step fix for L2 team reference",
  "rerun_safe": true or false,
  "reasoning": "Why this decision was made"
}}"""),

    ("human", """NEW INCIDENT:
Error: {error_code}
Module: {module}
Bot Version: {bot_version}
Stack Summary: {stack_summary}

RETRIEVED HISTORICAL INCIDENTS (top {k} matches):
{context}

TOP SIMILARITY SCORE: {top_score:.3f} | THRESHOLD: {threshold}

Produce JSON diagnostic response now.""")
])


def retrieve(query_text: str, vectorstore: FAISS) -> list[RetrievedMatch]:
    """Embed query and retrieve top-k similar docs from FAISS."""
    masked = mask_document(query_text)
    results = vectorstore.similarity_search_with_relevance_scores(
        masked, k=cfg.retrieval_top_k
    )
    matches = []
    for doc, score in results:
        matches.append(RetrievedMatch(
            content=doc.page_content,
            score=round(score, 4),
            metadata=doc.metadata,
            is_match=score >= cfg.similarity_threshold,
        ))
    if matches:
        logger.info(f"Top score: {matches[0].score:.4f} | Threshold: {cfg.similarity_threshold}")
    return matches


def diagnose(parsed_log: ParsedLog, vectorstore: FAISS) -> DiagnosticResult:
    """
    Full L1 triage — retrieve similar incidents, call GPT-4.1,
    parse structured JSON, apply safety overrides.
    """
    result = DiagnosticResult(parsed_log=parsed_log)

    if not parsed_log.is_valid:
        result.decision = "ESCALATE"
        result.plain_english_fix = (
            "We were unable to automatically analyse your error. "
            "Your issue will be escalated directly to the support team."
        )
        return result

    # Build query from structured fields
    query_text = (
        f"Error: {parsed_log.error_code}\n"
        f"Module: {parsed_log.module}\n"
        f"Stack: {parsed_log.stack_summary}"
    )

    matches = retrieve(query_text, vectorstore)
    result.matches = matches
    result.top_score = matches[0].score if matches else 0.0

    # Confidence band
    if result.top_score >= cfg.high_confidence_threshold:
        result.confidence_band = "HIGH"
    elif result.top_score >= cfg.similarity_threshold:
        result.confidence_band = "MEDIUM"
    else:
        result.confidence_band = "LOW"

    # Build context
    context_parts = []
    for i, m in enumerate(matches[:cfg.retrieval_top_k], 1):
        context_parts.append(
            f"--- Match {i} (score={m.score:.3f}) ---\n{m.content[:600]}"
        )
    context_str = "\n\n".join(context_parts) or "No historical matches found."

    # LLM call
    llm = _get_llm()
    prompt = DIAGNOSTIC_PROMPT.format_messages(
        error_code=parsed_log.error_code,
        module=parsed_log.module,
        bot_version=parsed_log.bot_version,
        stack_summary=parsed_log.stack_summary[:800],
        k=len(matches),
        context=context_str,
        top_score=result.top_score,
        threshold=cfg.similarity_threshold,
    )

    logger.info(f"Calling Diagnostic Agent | confidence={result.confidence_band}")
    response = _get_llm().invoke(prompt)
    raw = response.content.strip()
    result.raw_llm_response = raw

    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        logger.warning("LLM response not valid JSON — defaulting to ESCALATE")
        parsed = {
            "decision": "ESCALATE", "confidence_band": "LOW",
            "sop_summary": "Parse error — defaulting to escalation.",
            "plain_english_fix": (
                "We were unable to automatically diagnose this issue. "
                "Your case will be escalated to the support team."
            ),
            "suggested_fix": "", "rerun_safe": False,
            "reasoning": "JSON parse failure — safe fallback.",
        }

    result.decision        = parsed.get("decision", "ESCALATE")
    result.sop_summary     = parsed.get("sop_summary", "")
    result.plain_english_fix = parsed.get("plain_english_fix", "")
    result.suggested_fix   = parsed.get("suggested_fix", "")
    result.rerun_safe      = parsed.get("rerun_safe", False)
    result.reasoning       = parsed.get("reasoning", "")

    # Safety overrides — never auto-resolve below threshold
    if result.top_score < cfg.similarity_threshold:
        result.decision   = "ESCALATE"
        result.rerun_safe = False
        logger.info("Score below threshold — forced ESCALATE")

    if result.decision == "ESCALATE" or result.decision == "UNKNOWN":
        result.plain_english_fix = (
            "Our system could not automatically fix this issue. "
            "We are preparing your support ticket for the specialist team."
        )

    logger.info(
        f"Diagnosis complete | decision={result.decision} | "
        f"confidence={result.confidence_band} | rerun_safe={result.rerun_safe}"
    )
    return result
