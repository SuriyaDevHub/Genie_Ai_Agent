"""
masking.py — PII & financial identifier redaction layer.
Applied BEFORE any data is sent to the LLM or embedding endpoint.
Mandatory per CIB data governance design.
"""
from __future__ import annotations
import re
import hashlib
import logging
from config import cfg

logger = logging.getLogger(__name__)

_BUILTIN_PATTERNS = {
    "isin":         r"\b[A-Z]{2}[A-Z0-9]{10}\b",
    "trade_id":     r"\bTRADE[-_]?\d{6,12}\b",
    "account_num":  r"\bACC[-_]?\d{6,12}\b",
    "counterparty": r"(?i)(counterparty|cpty)\s*[:=]\s*\S+",
    "email":        r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b",
    "ip_address":   r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
    "windows_path": r"[A-Z]:\\(?:[^\\\n]+\\)*[^\\\n]*",
}


def mask_text(text: str) -> tuple[str, dict]:
    """
    Redact sensitive patterns. Returns (masked_text, audit_log).
    """
    if not text:
        return text, {}
    masked, audit = text, {}
    for name, pattern in _BUILTIN_PATTERNS.items():
        matches = re.findall(pattern, masked)
        if matches:
            masked = re.sub(pattern, f"[REDACTED_{name.upper()}]", masked)
            audit[name] = len(matches)
    for i, pattern in enumerate(cfg.masking_patterns):
        matches = re.findall(pattern, masked)
        if matches:
            masked = re.sub(pattern, "[REDACTED_CUSTOM]", masked)
            audit[f"custom_{i}"] = len(matches)
    if audit:
        logger.info(f"Masking applied — fields redacted: {list(audit.keys())}")
    return masked, audit


def mask_document(text: str) -> str:
    masked, _ = mask_text(text)
    return masked


def compute_error_hash(error_code: str, module: str, line_ref: str) -> str:
    """
    Generate stable fingerprint for deduplication.
    Same error across different users produces the same hash.
    """
    raw = f"{error_code.strip().lower()}|{module.strip().lower()}|{line_ref.strip().lower()}"
    return hashlib.md5(raw.encode()).hexdigest()[:16]
