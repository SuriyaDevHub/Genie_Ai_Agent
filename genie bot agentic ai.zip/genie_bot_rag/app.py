"""
app.py — Streamlit UI for Genie Bot Agentic AI Copilot
Non-IT business user interface — plain English throughout.
Embedded into C#.Net Genie Bot via WebView or launched as local Streamlit server.
"""
from __future__ import annotations
import os
import sys
from datetime import datetime, timezone

import streamlit as st

from pipeline import stage_diagnose, stage_rerun, stage_submit, stage_add_comment
from session_manager import get_or_create, WorkflowStage

# ── Page config ───────────────────────────────────────────────────────────
st.set_page_config(
    page_title="Genie Bot Support",
    page_icon="🤖",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# ── Custom CSS — clean, non-technical look for business users ─────────────
st.markdown("""
<style>
  .main { background: #f8f9fa; }
  .stButton > button {
    border-radius: 8px; font-weight: 600;
    padding: 0.6rem 1.4rem; font-size: 1rem;
  }
  .success-box {
    background: #d4edda; border-left: 5px solid #28a745;
    padding: 1rem 1.2rem; border-radius: 6px; margin: 1rem 0;
  }
  .warning-box {
    background: #fff3cd; border-left: 5px solid #ffc107;
    padding: 1rem 1.2rem; border-radius: 6px; margin: 1rem 0;
  }
  .info-box {
    background: #d1ecf1; border-left: 5px solid #17a2b8;
    padding: 1rem 1.2rem; border-radius: 6px; margin: 1rem 0;
  }
  .error-box {
    background: #f8d7da; border-left: 5px solid #dc3545;
    padding: 1rem 1.2rem; border-radius: 6px; margin: 1rem 0;
  }
  .ticket-badge {
    background: #1F3864; color: white;
    padding: 0.3rem 0.8rem; border-radius: 20px;
    font-weight: bold; font-size: 1.1rem;
  }
</style>
""", unsafe_allow_html=True)


# ── Session state init ────────────────────────────────────────────────────
def _init_ss():
    defaults = {
        "stage":          "IDLE",
        "run_id":         "",
        "user_id":        "",
        "machine_id":     "",
        "bot_install":    "",
        "timestamp":      "",
        "result":         None,
        "diagnostic":     None,
        "parsed_log":     None,
        "template":       None,
        "existing_ticket": "",
        "dedup_scenario": "",
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_ss()


# ── Helpers ───────────────────────────────────────────────────────────────
def _box(content: str, kind: str = "info"):
    st.markdown(f'<div class="{kind}-box">{content}</div>', unsafe_allow_html=True)


def _ticket_badge(key: str):
    st.markdown(f'<span class="ticket-badge">🎫 {key}</span>', unsafe_allow_html=True)


def _spinner_msg(msg: str):
    return st.spinner(f"⏳ {msg}")


# ── Header ────────────────────────────────────────────────────────────────
def _render_header():
    col1, col2 = st.columns([3, 1])
    with col1:
        st.title("🤖 Genie Bot Support")
        st.caption("Powered by Agentic AI — your automated support assistant")
    with col2:
        st.caption(f"Run ID: `{st.session_state.run_id or '—'}`")
        if st.session_state.stage != "IDLE":
            if st.button("🔄 Start Over", key="reset_top"):
                for k in list(st.session_state.keys()):
                    del st.session_state[k]
                st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PANEL 1 — Entry / Idle
# ════════════════════════════════════════════════════════════════════════════
def _panel_idle():
    _box(
        "Something went wrong with your Genie Bot? Click <b>Diagnose My Issue</b> "
        "below and our AI assistant will analyse the problem and suggest a fix.",
        "info"
    )

    st.markdown("---")

    with st.form("entry_form"):
        st.markdown("#### Your Details")
        col1, col2 = st.columns(2)
        with col1:
            user_id = st.text_input(
                "Your User ID",
                value=os.getenv("USER", ""),
                help="Your network login ID"
            )
        with col2:
            machine_id = st.text_input(
                "Machine / PC Name",
                value=os.getenv("COMPUTERNAME", ""),
                help="Your computer name (shown in System Properties)"
            )

        run_id = st.text_input(
            "Run ID from Genie Bot Error",
            placeholder="e.g. GBT-20260515-0042",
            help="Found in the red error message on the Genie Bot screen"
        )

        bot_install = st.text_input(
            "Genie Bot Folder Path",
            value=os.getenv("GENIE_BOT_PATH", r"C:\GenieBot"),
            help="The folder where Genie Bot is installed on your PC"
        )

        # For testing: allow log text paste
        with st.expander("🔧 Testing Mode — Paste Log Text Directly"):
            test_log = st.text_area(
                "Paste log content here (bypasses S3 — for PoC testing only)",
                height=150,
            )

        submitted = st.form_submit_button(
            "🔍 Diagnose My Issue",
            type="primary",
            use_container_width=True,
        )

    if submitted:
        if not run_id.strip():
            st.error("Please enter the Run ID from the Genie Bot error screen.")
            return
        if not user_id.strip():
            st.error("Please enter your User ID.")
            return

        st.session_state.run_id      = run_id.strip()
        st.session_state.user_id     = user_id.strip()
        st.session_state.machine_id  = machine_id.strip()
        st.session_state.bot_install = bot_install.strip()
        st.session_state.timestamp   = datetime.now(timezone.utc).isoformat()
        st.session_state.stage       = "DIAGNOSING"
        st.session_state._test_log   = test_log.strip() if test_log.strip() else None
        st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PANEL 2 — Running diagnosis
# ════════════════════════════════════════════════════════════════════════════
def _panel_diagnosing():
    _box("Our AI is analysing your error. This usually takes 15–30 seconds.", "info")

    with _spinner_msg("Fetching your logs and diagnosing the issue..."):
        result = stage_diagnose(
            run_id=st.session_state.run_id,
            user_id=st.session_state.user_id,
            machine_id=st.session_state.machine_id,
            timestamp=st.session_state.timestamp,
            bot_install_path=st.session_state.bot_install,
            local_log_text=st.session_state.get("_test_log"),
        )

    st.session_state.result = result
    st.session_state.stage  = result["stage"]

    if result["stage"] == "AWAITING_USER_FIX":
        st.session_state.diagnostic  = result["diagnostic"]
        st.session_state.parsed_log  = result["parsed_log"]

    if result["stage"] in ("AWAITING_SUBMIT",):
        st.session_state.template   = result.get("template")
        st.session_state.diagnostic = result.get("diagnostic")
        st.session_state.parsed_log = result.get("parsed_log")

    st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PANEL 3 — Dedup blocked
# ════════════════════════════════════════════════════════════════════════════
def _panel_dedup_blocked():
    result = st.session_state.result
    scenario = result.get("scenario", "")

    if "DUPLICATE_SAME_RUN" in scenario:
        _box(result["message"], "info")
        if result.get("existing_ticket"):
            _ticket_badge(result["existing_ticket"])

    elif "RECURRING_SAME_USER" in scenario:
        _box(result["message"], "warning")
        if result.get("existing_ticket"):
            _ticket_badge(result["existing_ticket"])
        st.markdown("---")
        st.markdown("#### Would you like to add a note?")
        comment = st.text_area(
            "Add a comment to your existing ticket (optional)",
            placeholder="e.g. Issue is still happening as of this morning...",
        )
        if st.button("📝 Add Note", type="primary") and comment.strip():
            with _spinner_msg("Adding your note..."):
                r = stage_add_comment(result["existing_ticket"], st.session_state.user_id, comment)
            _box(r["message"], "success")

    elif "SAME_ISSUE_DIFF_USER" in scenario:
        _box(result["message"], "info")
        if result.get("existing_ticket"):
            _ticket_badge(result["existing_ticket"])
        st.info(
            "💡 No action needed from you. The support team will contact you "
            "when the issue is resolved."
        )


# ════════════════════════════════════════════════════════════════════════════
# PANEL 4 — HITL Gate 1: Show L1 fix to user
# ════════════════════════════════════════════════════════════════════════════
def _panel_awaiting_user_fix():
    result     = st.session_state.result
    diagnostic = st.session_state.diagnostic

    confidence_colour = {
        "HIGH":   "success", "MEDIUM": "warning", "LOW": "error"
    }.get(result.get("confidence_band", "LOW"), "info")

    _box(result.get("message", ""), "info")

    if result.get("dedup_message"):
        _box(result["dedup_message"], "warning")

    st.markdown("---")
    st.markdown("### 💡 What the AI Found")

    conf = result.get("confidence_band", "")
    st.markdown(f"**Confidence Level:** `{conf}` match in our knowledge base")

    st.markdown("### 🔧 Suggested Fix")
    _box(result.get("plain_english_fix", ""), confidence_colour)

    st.markdown("---")
    st.markdown("### What would you like to do?")

    col1, col2 = st.columns(2)

    with col1:
        if result.get("rerun_safe"):
            if st.button(
                "✅ Try Fix & Re-run Bot",
                type="primary",
                use_container_width=True,
                key="btn_rerun",
            ):
                st.session_state.stage = "RERUNNING"
                st.rerun()
        else:
            st.info(
                "⚠️ Automatic re-run is not available for this error type. "
                "Please apply the fix manually, then click the button below."
            )
            if st.button(
                "✅ I've Applied the Fix — Check Again",
                type="primary",
                use_container_width=True,
                key="btn_manual_fix",
            ):
                st.session_state.stage = "RERUNNING"
                st.rerun()

    with col2:
        if st.button(
            "📩 Skip Fix — Escalate to Support Team",
            use_container_width=True,
            key="btn_skip",
        ):
            st.session_state.stage = "GENERATING_TEMPLATE_DIRECT"
            st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PANEL 5 — Rerunning
# ════════════════════════════════════════════════════════════════════════════
def _panel_rerunning():
    _box("Applying the fix and restarting Genie Bot. Please wait...", "info")

    with _spinner_msg("Re-running Genie Bot..."):
        result = stage_rerun(
            run_id=st.session_state.run_id,
            user_id=st.session_state.user_id,
            diagnostic=st.session_state.diagnostic,
            parsed_log=st.session_state.parsed_log,
            bot_install_path=st.session_state.bot_install,
        )

    st.session_state.result = result
    st.session_state.stage  = result["stage"]

    if result["stage"] == "AWAITING_SUBMIT":
        st.session_state.template = result.get("template")

    st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PANEL 6 — Generate template directly (user skipped fix)
# ════════════════════════════════════════════════════════════════════════════
def _panel_generate_template_direct():
    from template_generator import generate as gen_template

    with _spinner_msg("Preparing your support ticket..."):
        template = gen_template(
            diagnostic=st.session_state.diagnostic,
            user_id=st.session_state.user_id,
        )
    st.session_state.template = template
    st.session_state.stage    = "AWAITING_SUBMIT"
    st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PANEL 7 — HITL Gate 2: Review pre-filled template before submit
# ════════════════════════════════════════════════════════════════════════════
def _panel_awaiting_submit():
    result   = st.session_state.result or {}
    template = st.session_state.template

    _box(result.get("message", "Please review your support ticket below before submitting."), "warning")

    st.markdown("---")
    st.markdown("### 📋 Your Pre-filled Support Ticket")
    st.caption("Our AI has filled this in for you. Please review and add any extra details.")

    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"**Issue:** {template.error_summary}")
        st.markdown(f"**Area:** {template.affected_module}")
        st.markdown(f"**Priority:** `{template.priority}`")
    with col2:
        st.markdown(f"**Run ID:** `{template.run_id}`")
        st.markdown(f"**Bot Version:** `{template.bot_version}`")
        st.markdown(f"**Classification:** {template.error_classification}")

    st.markdown("**What happened:**")
    st.info(template.stack_trace_summary)

    if template.l1_fix_attempted:
        st.markdown("**Fix already tried:**")
        fix_status = "✅ Fix applied but issue persisted" if not template.rerun_outcome == "SUCCESS" else "✅ Fixed"
        _box(f"{fix_status}\n\nFix attempted: {template.l1_fix_suggested}", "warning")

    if template.similar_ticket_ids:
        st.markdown(f"**Related tickets:** {', '.join(template.similar_ticket_ids)}")

    if template.link_to_ticket:
        st.markdown(f"**Linked to:** {template.link_to_ticket}")

    st.markdown("---")
    st.markdown("#### ✏️ Add Any Extra Details (Optional)")
    user_comments = st.text_area(
        "Any additional information for the support team?",
        placeholder="e.g. This started happening after the system update last Friday...",
        height=120,
    )

    st.markdown("---")
    col_submit, col_cancel = st.columns(2)

    with col_submit:
        if st.button(
            "🚀 Submit to Support Team",
            type="primary",
            use_container_width=True,
            key="btn_submit",
        ):
            with _spinner_msg("Raising your support ticket..."):
                result = stage_submit(
                    run_id=st.session_state.run_id,
                    user_id=st.session_state.user_id,
                    machine_id=st.session_state.machine_id,
                    template=template,
                    diagnostic=st.session_state.diagnostic,
                    user_comments=user_comments,
                )
            st.session_state.result = result
            st.session_state.stage  = result["stage"]
            st.rerun()

    with col_cancel:
        if st.button("← Go Back", use_container_width=True, key="btn_back"):
            st.session_state.stage = "AWAITING_USER_FIX"
            st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PANEL 8 — Resolved (L1 success)
# ════════════════════════════════════════════════════════════════════════════
def _panel_resolved():
    result = st.session_state.result
    _box("🎉 " + result.get("message", "Issue resolved!"), "success")
    st.markdown("---")
    st.markdown("**Your resolution has been logged:**")
    _ticket_badge(result.get("jira_ticket", ""))
    st.caption(result.get("jira_message", ""))
    st.balloons()

    if st.button("✅ Done", use_container_width=True):
        for k in list(st.session_state.keys()):
            del st.session_state[k]
        st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PANEL 9 — Escalated (L2 ticket created)
# ════════════════════════════════════════════════════════════════════════════
def _panel_escalated():
    result = st.session_state.result
    _box(result.get("message", "Your ticket has been raised."), "success")
    st.markdown("---")
    st.markdown("**Your support ticket reference:**")
    _ticket_badge(result.get("jira_ticket", ""))
    st.info(
        "📧 The specialist support team has been notified. "
        "Please keep this reference number for any follow-up queries."
    )

    if st.button("✅ Done", use_container_width=True):
        for k in list(st.session_state.keys()):
            del st.session_state[k]
        st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# PANEL 10 — Error
# ════════════════════════════════════════════════════════════════════════════
def _panel_error():
    result = st.session_state.result or {}
    _box(result.get("message", "An unexpected error occurred."), "error")
    st.error("Please contact the support team directly if this persists.")

    if st.button("🔄 Try Again"):
        for k in list(st.session_state.keys()):
            del st.session_state[k]
        st.rerun()


# ════════════════════════════════════════════════════════════════════════════
# ROUTER — maps stage → panel
# ════════════════════════════════════════════════════════════════════════════
def main():
    _render_header()
    st.markdown("---")

    stage = st.session_state.stage

    stage_map = {
        "IDLE":                     _panel_idle,
        "DIAGNOSING":               _panel_diagnosing,
        "DEDUP_BLOCKED":            _panel_dedup_blocked,
        "AWAITING_USER_FIX":        _panel_awaiting_user_fix,
        "RERUNNING":                _panel_rerunning,
        "GENERATING_TEMPLATE_DIRECT": _panel_generate_template_direct,
        "AWAITING_SUBMIT":          _panel_awaiting_submit,
        "RESOLVED":                 _panel_resolved,
        "ESCALATED":                _panel_escalated,
        "COOLDOWN":                 lambda: _box(
            st.session_state.result.get("message", "Please wait before retrying."), "warning"
        ),
        "ERROR":                    _panel_error,
    }

    panel_fn = stage_map.get(stage, _panel_idle)
    panel_fn()

    # Footer
    st.markdown("---")
    st.caption("🔒 Genie Bot Support Copilot | CIB Middle Office | Powered by Agentic AI")


if __name__ == "__main__":
    main()
