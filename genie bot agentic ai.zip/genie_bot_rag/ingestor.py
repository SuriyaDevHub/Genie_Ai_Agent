"""
ingestor.py — Document ingestion & FAISS vector store builder
Handles: Jira CSV exports, raw S3 log files, SOP text documents.
Applies masking before embedding. Saves FAISS index to disk.
"""
import os
import csv
import json
import logging
from pathlib import Path
from typing import List

from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_openai import AzureOpenAIEmbeddings
from langchain_community.vectorstores import FAISS

from config import cfg
from masking import mask_document

logger = logging.getLogger(__name__)


# ── Embeddings client ─────────────────────────────────────────────────────
def get_embeddings() -> AzureOpenAIEmbeddings:
    return AzureOpenAIEmbeddings(
        azure_deployment=cfg.embedding_deployment,
        azure_endpoint=cfg.azure_openai_endpoint,
        api_key=cfg.azure_openai_api_key,
        api_version=cfg.azure_openai_api_version,
        dimensions=cfg.embedding_dimensions,
    )


# ── Loaders ───────────────────────────────────────────────────────────────
def load_jira_csv(filepath: str) -> List[Document]:
    """
    Load resolved Jira tickets from CSV export.
    Expected columns: ticket_id, run_id, summary, root_cause,
                      resolution, priority, date_created, date_resolved
    """
    docs = []
    with open(filepath, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Build a rich text representation of the incident
            content = (
                f"Ticket: {row.get('ticket_id', 'N/A')}\n"
                f"Run ID: {row.get('run_id', 'N/A')}\n"
                f"Summary: {row.get('summary', '')}\n"
                f"Root Cause: {row.get('root_cause', '')}\n"
                f"Resolution: {row.get('resolution', '')}\n"
                f"Priority: {row.get('priority', '')}\n"
            )
            masked_content = mask_document(content)
            docs.append(Document(
                page_content=masked_content,
                metadata={
                    "source":       "jira",
                    "ticket_id":    row.get("ticket_id", ""),
                    "run_id":       row.get("run_id", ""),
                    "priority":     row.get("priority", ""),
                    "date_created": row.get("date_created", ""),
                    "filepath":     filepath,
                }
            ))
    logger.info(f"Loaded {len(docs)} Jira tickets from {filepath}")
    return docs


def load_log_file(filepath: str) -> List[Document]:
    """
    Load a raw Genie Bot S3 execution log file.
    Each file = one document (chunked downstream).
    """
    with open(filepath, "r", encoding="utf-8", errors="replace") as f:
        raw_text = f.read()

    masked_text = mask_document(raw_text)
    doc = Document(
        page_content=masked_text,
        metadata={
            "source":   "s3_log",
            "filename": Path(filepath).name,
            "filepath": filepath,
        }
    )
    logger.info(f"Loaded log file: {Path(filepath).name}")
    return [doc]


def load_sop_text(filepath: str) -> List[Document]:
    """
    Load a plain text SOP / runbook document.
    """
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    masked_content = mask_document(content)
    doc = Document(
        page_content=masked_content,
        metadata={
            "source":   "sop",
            "filename": Path(filepath).name,
            "filepath": filepath,
        }
    )
    logger.info(f"Loaded SOP document: {Path(filepath).name}")
    return [doc]


def load_folder(folder_path: str) -> List[Document]:
    """
    Auto-detect and load all supported files in a folder.
    Supported: .csv (Jira), .log/.txt (S3 logs), .md (SOP docs)
    """
    all_docs = []
    folder = Path(folder_path)

    for file in folder.rglob("*"):
        if file.suffix == ".csv":
            all_docs.extend(load_jira_csv(str(file)))
        elif file.suffix in (".log", ".txt"):
            all_docs.extend(load_log_file(str(file)))
        elif file.suffix in (".md",):
            all_docs.extend(load_sop_text(str(file)))

    logger.info(f"Total documents loaded from folder: {len(all_docs)}")
    return all_docs


# ── Chunking ──────────────────────────────────────────────────────────────
def chunk_documents(docs: List[Document]) -> List[Document]:
    """Split large documents into chunks for embedding."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=cfg.chunk_size,
        chunk_overlap=cfg.chunk_overlap,
        separators=["\n\n", "\n", " ", ""],
    )
    chunks = splitter.split_documents(docs)
    logger.info(f"Chunked {len(docs)} documents into {len(chunks)} chunks")
    return chunks


# ── FAISS index builder ───────────────────────────────────────────────────
def build_index(docs: List[Document], save: bool = True) -> FAISS:
    """
    Embed documents and build FAISS index.
    Saves to disk at cfg.faiss_index_path if save=True.
    """
    if not docs:
        raise ValueError("No documents provided for indexing.")

    embeddings = get_embeddings()
    chunks = chunk_documents(docs)

    logger.info(f"Building FAISS index from {len(chunks)} chunks...")
    vectorstore = FAISS.from_documents(chunks, embeddings)

    if save:
        os.makedirs(cfg.faiss_index_path, exist_ok=True)
        vectorstore.save_local(cfg.faiss_index_path)
        logger.info(f"FAISS index saved to: {cfg.faiss_index_path}")

    return vectorstore


def load_index() -> FAISS:
    """Load an existing FAISS index from disk."""
    if not os.path.exists(cfg.faiss_index_path):
        raise FileNotFoundError(
            f"No FAISS index found at {cfg.faiss_index_path}. "
            "Run build_index() first."
        )
    embeddings = get_embeddings()
    vectorstore = FAISS.load_local(
        cfg.faiss_index_path,
        embeddings,
        allow_dangerous_deserialization=True,
    )
    logger.info(f"FAISS index loaded from: {cfg.faiss_index_path}")
    return vectorstore


def update_index(new_docs: List[Document]) -> FAISS:
    """
    Add new documents to an existing FAISS index.
    Used when new resolved Jira tickets are written post-resolution.
    """
    vectorstore = load_index()
    chunks = chunk_documents(new_docs)
    embeddings = get_embeddings()

    vectorstore.add_documents(chunks)
    vectorstore.save_local(cfg.faiss_index_path)
    logger.info(f"Index updated with {len(chunks)} new chunks.")
    return vectorstore
