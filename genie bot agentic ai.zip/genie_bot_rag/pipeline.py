"""
pipeline.py — Main orchestrator for all 6 agents.
Called by app.py (Streamlit) at each workflow stage.
Also supports CLI for testing.
"""
from __future__ import annotations
import logging
import sys
from pathlib import Path

from config import cfg
from s3_agent import fetch_and_parse, ParsedLog
from dedup_agent import check as dedup_check, DedupScenario
from retriever import diagnose
from rerun_agent import attempt_rerun
from template_generator import generate as gen_template
from jira_agent import create_resolved_ticket, create_escalation_ticket, add_comment
from session_manager import get_or_create, save_audit, WorkflowStage
from ingestor import load_folder, build_index, load_index, update_index

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("rag_pipeline.log"),
    ]
)
logger = logging.getLogger(__name__)


# ═══════════════════════════════════════════════════════════════════════════
# STAGE 1 — User clicks "Diagnose Issue"
# ═══════════════════════════════════════════════════════════════════════════
def stage_diagnose(
    run_id: str,
    user_id: str,
    machine_id: str,
    timestamp: str,
    bot_install_path: str,
    local_log_text: str = None,   # For testing — bypass S3
) -> dict:
    """
    Runs: Log Parser → Dedup Check → Diagnostic Agent
    Returns state for Streamlit to render next UI panel.
    """
    session = get_or_create(user_id, machine_id, run_id)
    session.advance(WorkflowStage.FETCHING_LOG, "User clicked Diagnose Issue")

    # ── Agent 1: Fetch & parse log ────────────────────────────────────
    parsed_log = fetch_and_parse(
        run_id=run_id, timestamp=timestamp,
        user_id=user_id, machine_id=machine_id,
        local_log_text=local_log_text,
    )
    session.error_hash  = parsed_log.error_hash
    session.bot_version = parsed_log.bot_version

    if parsed_log.fetch_error:
        session.advance(WorkflowStage.ERROR, parsed_log.fetch_error)
        return {"stage": "ERROR", "message": (
            "We were unable to retrieve your error log automatically. "
            "Please contact the support team directly."
        )}

    # ── Agent 2: Deduplication check ─────────────────────────────────
    session.advance(WorkflowStage.DEDUP_CHECK)
    dedup = dedup_check(parsed_log)
    session.dedup_scenario  = dedup.scenario.value
    session.existing_ticket = dedup.existing_ticket or ""

    if not dedup.proceed_to_diag:
        session.advance(
            WorkflowStage.COMPLETE,
            f"Dedup blocked — scenario={dedup.scenario.value} ticket={dedup.existing_ticket}"
        )
        save_audit(session)
        return {
            "stage":           "DEDUP_BLOCKED",
            "scenario":        dedup.scenario.value,
            "existing_ticket": dedup.existing_ticket,
            "message":         dedup.user_message,
            "allow_comment":   dedup.scenario.value in (
                DedupScenario.RECURRING_SAME_USER.value,
                DedupScenario.SAME_ISSUE_DIFF_USER.value,
            ),
        }

    # ── Agent 3: Diagnose ─────────────────────────────────────────────
    session.advance(WorkflowStage.DIAGNOSING)
    try:
        vectorstore = load_index()
    except FileNotFoundError:
        logger.warning("No FAISS index found — escalating directly")
        session.advance(WorkflowStage.GENERATING_TEMPLATE, "No vector index — direct escalate")
        template = gen_template(
            diagnostic=type('D', (), {
                'parsed_log': parsed_log, 'decision': 'ESCALATE',
                'confidence_band': 'LOW', 'top_score': 0.0,
                'sop_summary': 'No knowledge base available.',
                'plain_english_fix': '', 'suggested_fix': '',
                'rerun_safe': False, 'reasoning': '',
                'matches': [],
            })(),
            user_id=user_id,
        )
        session.advance(WorkflowStage.AWAITING_SUBMIT)
        return {
            "stage":    "AWAITING_SUBMIT",
            "template": template,
            "message":  "No knowledge base found — escalating directly to support team.",
        }

    diagnostic = diagnose(parsed_log, vectorstore)
    session.decision          = diagnostic.decision
    session.confidence_band   = diagnostic.confidence_band
    session.plain_english_fix = diagnostic.plain_english_fix
    session.rerun_safe        = diagnostic.rerun_safe

    # ── Branch: LOW confidence → skip straight to L2 ──────────────────
    if diagnostic.decision in ("ESCALATE", "UNKNOWN"):
        session.advance(WorkflowStage.GENERATING_TEMPLATE, "Low confidence — direct escalate")
        template = gen_template(
            diagnostic=diagnostic,
            link_to_ticket=dedup.link_to_ticket or "",
            user_id=user_id,
        )
        session.template_generated = True
        session.advance(WorkflowStage.AWAITING_SUBMIT)
        save_audit(session)
        return {
            "stage":    "AWAITING_SUBMIT",
            "template": template,
            "message": (
                "This looks like a new or complex issue. "
                "We've prepared your support ticket — please review and submit."
            ),
            "dedup_message": dedup.user_message,
        }

    # ── Branch: HIGH/MEDIUM confidence → show L1 fix to user ──────────
    session.advance(WorkflowStage.AWAITING_USER_FIX, "L1 fix available — HITL Gate 1")
    save_audit(session)
    return {
        "stage":            "AWAITING_USER_FIX",
        "plain_english_fix": diagnostic.plain_english_fix,
        "rerun_safe":        diagnostic.rerun_safe,
        "confidence_band":   diagnostic.confidence_band,
        "diagnostic":        diagnostic,
        "parsed_log":        parsed_log,
        "bot_install_path":  bot_install_path,
        "dedup_message":     dedup.user_message,
        "message": (
            "We found a potential fix for your issue. "
            "Please try the steps below and click Re-run."
        ),
    }


# ═══════════════════════════════════════════════════════════════════════════
# STAGE 2A — User clicks "Try Fix & Re-run"
# ═══════════════════════════════════════════════════════════════════════════
def stage_rerun(
    run_id: str,
    user_id: str,
    diagnostic,
    parsed_log: ParsedLog,
    bot_install_path: str,
) -> dict:
    """
    Runs: Rerun Agent → branch on success/failure.
    """
    session = get_or_create(user_id, parsed_log.machine_id, run_id)

    if session.is_within_cooldown():
        return {
            "stage":   "COOLDOWN",
            "message": (
                "A rerun was attempted recently. Please wait a few minutes "
                "before trying again."
            ),
        }

    session.advance(WorkflowStage.RERUNNING)
    rerun = attempt_rerun(
        bot_install_path=bot_install_path,
        run_id=run_id,
        rerun_safe=diagnostic.rerun_safe,
    )

    from datetime import datetime, timezone
    session.rerun_attempted  = True
    session.rerun_success    = rerun.success
    session.rerun_timestamp  = datetime.now(timezone.utc).isoformat()

    # ── Rerun SUCCESS → create DONE Jira ticket ───────────────────────
    if rerun.success:
        session.advance(WorkflowStage.CREATING_TICKET, "Rerun succeeded")
        jira = create_resolved_ticket(diagnostic, rerun)
        session.jira_ticket_key = jira.ticket_key
        session.jira_ticket_url = jira.ticket_url
        session.mark_complete()
        save_audit(session)
        return {
            "stage":        "RESOLVED",
            "jira_ticket":  jira.ticket_key,
            "jira_url":     jira.ticket_url,
            "message":      rerun.user_message,
            "jira_message": jira.user_message,
        }

    # ── Rerun FAILED → generate L2 template ──────────────────────────
    session.advance(WorkflowStage.GENERATING_TEMPLATE, "Rerun failed — escalating")
    template = gen_template(
        diagnostic=diagnostic,
        rerun_result=rerun,
        user_id=user_id,
    )
    session.template_generated = True
    session.advance(WorkflowStage.AWAITING_SUBMIT)
    save_audit(session)
    return {
        "stage":    "AWAITING_SUBMIT",
        "template": template,
        "message":  rerun.user_message,
    }


# ═══════════════════════════════════════════════════════════════════════════
# STAGE 2B — User clicks "Submit to L2"
# ═══════════════════════════════════════════════════════════════════════════
def stage_submit(
    run_id: str,
    user_id: str,
    machine_id: str,
    template,
    diagnostic,
    user_comments: str = "",
) -> dict:
    """
    User submits the reviewed L2 template.
    Creates Jira OPEN ticket with template + log attached.
    """
    session = get_or_create(user_id, machine_id, run_id)
    template.user_additional_comments = user_comments
    session.user_comments = user_comments
    session.advance(WorkflowStage.CREATING_TICKET, "User submitted L2 template")

    jira = create_escalation_ticket(template, diagnostic)
    session.jira_ticket_key = jira.ticket_key
    session.jira_ticket_url = jira.ticket_url
    session.mark_complete()
    save_audit(session)

    return {
        "stage":       "ESCALATED",
        "jira_ticket": jira.ticket_key,
        "jira_url":    jira.ticket_url,
        "message":     jira.user_message,
    }


# ═══════════════════════════════════════════════════════════════════════════
# STAGE 3 — User adds comment to existing ticket (dedup scenarios)
# ═══════════════════════════════════════════════════════════════════════════
def stage_add_comment(ticket_key: str, user_id: str, comment: str) -> dict:
    result = add_comment(ticket_key, f"User {user_id} update: {comment}")
    return {"stage": "COMMENT_ADDED", "message": result.user_message}


# ═══════════════════════════════════════════════════════════════════════════
# INGESTION — run once to seed vector DB
# ═══════════════════════════════════════════════════════════════════════════
def run_ingestion(data_folder: str = "./data") -> None:
    cfg.validate()
    docs = load_folder(data_folder)
    if not docs:
        logger.error(f"No documents found in {data_folder}")
        return
    build_index(docs, save=True)
    logger.info("Ingestion complete.")


# ═══════════════════════════════════════════════════════════════════════════
# CLI ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    import argparse
    from datetime import datetime, timezone

    parser = argparse.ArgumentParser(description="Genie Bot Agentic AI Pipeline")
    sub = parser.add_subparsers(dest="command")

    ingest_p = sub.add_parser("ingest")
    ingest_p.add_argument("--data", default="./data")

    diag_p = sub.add_parser("diagnose")
    diag_p.add_argument("--log",       required=True)
    diag_p.add_argument("--run-id",    default="CLI-TEST-001")
    diag_p.add_argument("--user-id",   default="cli_user")
    diag_p.add_argument("--bot-path",  default="./")

    args = parser.parse_args()

    if args.command == "ingest":
        run_ingestion(args.data)

    elif args.command == "diagnose":
        log_text = Path(args.log).read_text(encoding="utf-8", errors="replace")
        result = stage_diagnose(
            run_id=args.run_id,
            user_id=args.user_id,
            machine_id="CLI",
            timestamp=datetime.now(timezone.utc).isoformat(),
            bot_install_path=args.bot_path,
            local_log_text=log_text,
        )
        print(f"\nStage:   {result['stage']}")
        print(f"Message: {result.get('message', '')}")
        if result.get("plain_english_fix"):
            print(f"L1 Fix:  {result['plain_english_fix']}")
        if result.get("template"):
            t = result["template"]
            print(f"Template: {t.error_summary} | Priority: {t.priority}")
    else:
        parser.print_help()
