"""
config.py — Central configuration for Genie Bot Agentic AI Pipeline
All settings loaded from environment variables. Never hardcode credentials.
"""
from __future__ import annotations
import os
from dataclasses import dataclass, field


@dataclass
class Config:
    # ── Azure OpenAI ──────────────────────────────────────────────────
    azure_openai_endpoint: str     = os.getenv("AZURE_OPENAI_ENDPOINT", "")
    azure_openai_api_key: str      = os.getenv("AZURE_OPENAI_API_KEY", "")
    azure_openai_api_version: str  = os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01")

    # ── Model Deployments ─────────────────────────────────────────────
    llm_deployment: str            = os.getenv("LLM_DEPLOYMENT", "gpt-4.1")
    embedding_deployment: str      = os.getenv("EMBEDDING_DEPLOYMENT", "text-embedding-3-small")

    # ── LLM Settings ─────────────────────────────────────────────────
    llm_temperature: float         = 0.0      # Deterministic — mandatory for triage
    llm_max_tokens: int            = 1000

    # ── Embedding Settings ────────────────────────────────────────────
    embedding_dimensions: int      = 1536

    # ── AWS S3 ───────────────────────────────────────────────────────
    aws_access_key_id: str         = os.getenv("AWS_ACCESS_KEY_ID", "")
    aws_secret_access_key: str     = os.getenv("AWS_SECRET_ACCESS_KEY", "")
    aws_region: str                = os.getenv("AWS_REGION", "eu-west-1")
    s3_bucket_name: str            = os.getenv("S3_BUCKET_NAME", "genie-bot-logs")
    s3_log_prefix: str             = os.getenv("S3_LOG_PREFIX", "prod/")

    # ── Jira ─────────────────────────────────────────────────────────
    jira_base_url: str             = os.getenv("JIRA_BASE_URL", "")
    jira_api_token: str            = os.getenv("JIRA_API_TOKEN", "")
    jira_user_email: str           = os.getenv("JIRA_USER_EMAIL", "")
    jira_project_key: str          = os.getenv("JIRA_PROJECT_KEY", "GBOT")
    jira_l2_queue_label: str       = "genie-bot-l2"

    # ── FAISS Vector Store ────────────────────────────────────────────
    faiss_index_path: str          = os.getenv("FAISS_INDEX_PATH", "./faiss_index")

    # ── Retrieval & Deduplication ─────────────────────────────────────
    retrieval_top_k: int           = 5
    similarity_threshold: float    = 0.75   # Below = LOW confidence → straight to L2
    high_confidence_threshold: float = 0.85 # Above = AUTO_RESOLVE candidate
    dedup_similarity_threshold: float = 0.85 # For fuzzy Jira dedup match
    rerun_cooldown_minutes: int    = 30     # Min gap before allowing second rerun
    multi_user_priority_threshold: int = 3  # Users hitting same error → escalate priority

    # ── Chunking ──────────────────────────────────────────────────────
    chunk_size: int                = 500
    chunk_overlap: int             = 50

    # ── Masking Patterns ─────────────────────────────────────────────
    masking_patterns: list         = field(default_factory=lambda: [
        r"\b[A-Z]{2}\d{10}\b",          # ISIN codes
        r"\bTRADE[-_]?\d{6,12}\b",       # Trade IDs
        r"\bACC[-_]?\d{6,12}\b",         # Account numbers
        r"\b\d{8,12}\b",                 # Generic numeric IDs
    ])

    def validate(self):
        missing = [k for k, v in {
            "AZURE_OPENAI_ENDPOINT": self.azure_openai_endpoint,
            "AZURE_OPENAI_API_KEY":  self.azure_openai_api_key,
            "JIRA_BASE_URL":         self.jira_base_url,
            "JIRA_API_TOKEN":        self.jira_api_token,
            "JIRA_USER_EMAIL":       self.jira_user_email,
        }.items() if not v]
        if missing:
            raise EnvironmentError(
                f"Missing required environment variables: {', '.join(missing)}\n"
                "Copy .env.example to .env and fill in your values."
            )


cfg = Config()
