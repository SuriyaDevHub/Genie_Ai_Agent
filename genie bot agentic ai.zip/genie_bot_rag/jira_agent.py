"""
jira_agent.py — Agent 6: Jira Agent
Handles ALL Jira operations:
  - Create DONE ticket (L1 resolved)
  - Create OPEN ticket (L2 escalation) with template + log attachment
  - Append comment to existing ticket
  - Duplicate prevention via error_hash custom field
"""
from __future__ import annotations
import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import requests
from requests.auth import HTTPBasicAuth

from config import cfg
from retriever import DiagnosticResult
from rerun_agent import RerunResult
from template_generator import EscalationTemplate

logger = logging.getLogger(__name__)


@dataclass
class JiraTicketResult:
    success:    bool
    ticket_key: str = ""
    ticket_url: str = ""
    action:     str = ""   # "created_done" | "created_open" | "comment_added" | "failed"
    error:      str = ""

    @property
    def user_message(self) -> str:
        if not self.success:
            return f"Ticket creation failed — {self.error}. Please contact support manually."
        if self.action == "created_done":
            return (
                f"Your issue has been resolved and logged. "
                f"Reference: **{self.ticket_key}** — no further action needed."
            )
        if self.action == "created_open":
            return (
                f"Your support ticket has been raised: **{self.ticket_key}**. "
                f"The specialist team will be in touch. "
                f"You can track progress using this reference."
            )
        if self.action == "comment_added":
            return f"Your comment has been added to ticket **{self.ticket_key}**."
        return f"Action completed. Reference: {self.ticket_key}"


def _auth() -> HTTPBasicAuth:
    return HTTPBasicAuth(cfg.jira_user_email, cfg.jira_api_token)


def _headers() -> dict:
    return {"Accept": "application/json", "Content-Type": "application/json"}


def _adf_text(text: str) -> dict:
    """Atlassian Document Format — plain text paragraph."""
    return {
        "type": "doc", "version": 1,
        "content": [{"type": "paragraph", "content": [{"type": "text", "text": text}]}]
    }


def _adf_full(template: EscalationTemplate) -> dict:
    """Build rich ADF description from escalation template."""
    def section(heading: str, body: str) -> list:
        return [
            {"type": "heading", "attrs": {"level": 3},
             "content": [{"type": "text", "text": heading}]},
            {"type": "paragraph", "content": [{"type": "text", "text": body or "N/A"}]},
        ]

    content = []
    content += section("Error Summary", template.error_summary)
    content += section("Affected Module", template.affected_module)
    content += section("Error Classification", template.error_classification)
    content += section("Stack Trace Summary", template.stack_trace_summary)
    content += section("SOP Reference", template.sop_reference)
    content += section("Bot Version", template.bot_version)

    # L1 attempt record
    l1_text = (
        f"L1 Fix Suggested: {template.l1_fix_suggested or 'None'}\n"
        f"L1 Fix Attempted: {'Yes' if template.l1_fix_attempted else 'No'}\n"
        f"Rerun Attempted:  {'Yes' if template.rerun_attempted else 'No'}\n"
        f"Rerun Outcome:    {template.rerun_outcome}\n"
        f"Escalation Reason: {template.escalation_reason}"
    )
    content += section("L1 Triage Record", l1_text)

    if template.user_additional_comments:
        content += section("User Additional Comments", template.user_additional_comments)

    if template.similar_ticket_ids:
        content += section("Similar Historical Tickets", ", ".join(template.similar_ticket_ids))

    content += section("AI Confidence Band", template.confidence_band)
    content += section("Run ID", template.run_id)
    content += section("Submitted By", template.submitted_by)
    content += section("Timestamp", template.timestamp)

    return {"type": "doc", "version": 1, "content": content}


def _create_ticket(
    summary: str,
    description: dict,
    priority: str,
    status_transition: str,
    error_hash: str,
    run_id: str,
    labels: list[str] = None,
    link_to: str = None,
) -> JiraTicketResult:
    """Core Jira ticket creation."""
    payload = {
        "fields": {
            "project":     {"key": cfg.jira_project_key},
            "summary":     summary,
            "description": description,
            "issuetype":   {"name": "Bug"},
            "priority":    {"name": priority},
            "labels":      (labels or []) + [cfg.jira_l2_queue_label],
            # Custom fields — adjust field IDs to match your Jira instance
            "customfield_10100": error_hash,   # Error Hash
            "customfield_10101": run_id,       # Run ID
        }
    }

    try:
        resp = requests.post(
            f"{cfg.jira_base_url}/rest/api/3/issue",
            auth=_auth(), headers=_headers(),
            json=payload, timeout=15,
        )
        resp.raise_for_status()
        issue = resp.json()
        ticket_key = issue["key"]
        ticket_url = f"{cfg.jira_base_url}/browse/{ticket_key}"
        logger.info(f"Jira ticket created: {ticket_key}")

        # Transition to target status
        _transition_ticket(ticket_key, status_transition)

        # Link to related ticket if provided
        if link_to:
            _link_tickets(ticket_key, link_to)

        return JiraTicketResult(success=True, ticket_key=ticket_key, ticket_url=ticket_url)

    except requests.HTTPError as e:
        err = f"Jira API error {e.response.status_code}: {e.response.text[:200]}"
        logger.error(err)
        return JiraTicketResult(success=False, error=err)
    except Exception as e:
        logger.error(f"Jira ticket creation failed: {e}")
        return JiraTicketResult(success=False, error=str(e))


def _transition_ticket(ticket_key: str, target_status: str):
    """Move ticket to target status via Jira workflow transition."""
    try:
        # Get available transitions
        resp = requests.get(
            f"{cfg.jira_base_url}/rest/api/3/issue/{ticket_key}/transitions",
            auth=_auth(), headers=_headers(), timeout=10,
        )
        resp.raise_for_status()
        transitions = resp.json().get("transitions", [])

        # Find matching transition
        target = next(
            (t for t in transitions if target_status.lower() in t["name"].lower()),
            None
        )
        if not target:
            logger.warning(f"Transition '{target_status}' not found for {ticket_key}")
            return

        requests.post(
            f"{cfg.jira_base_url}/rest/api/3/issue/{ticket_key}/transitions",
            auth=_auth(), headers=_headers(),
            json={"transition": {"id": target["id"]}},
            timeout=10,
        )
        logger.info(f"Ticket {ticket_key} transitioned to '{target_status}'")
    except Exception as e:
        logger.warning(f"Transition failed for {ticket_key}: {e}")


def _link_tickets(source: str, target: str):
    """Link source ticket to target as 'relates to'."""
    try:
        requests.post(
            f"{cfg.jira_base_url}/rest/api/3/issueLink",
            auth=_auth(), headers=_headers(),
            json={
                "type": {"name": "Relates"},
                "inwardIssue":  {"key": source},
                "outwardIssue": {"key": target},
            },
            timeout=10,
        )
        logger.info(f"Linked {source} → {target}")
    except Exception as e:
        logger.warning(f"Ticket linking failed: {e}")


def _attach_log(ticket_key: str, s3_path: str, run_id: str):
    """Attach a note about the S3 log location (attachment via URL comment)."""
    comment_text = (
        f"S3 Log Reference: s3://{cfg.s3_bucket_name}/{s3_path}\n"
        f"Run ID: {run_id}\n"
        f"Note: Full execution log available in S3 at the path above."
    )
    add_comment(ticket_key, comment_text)


# ── Public API ────────────────────────────────────────────────────────────

def create_resolved_ticket(
    diagnostic: DiagnosticResult,
    rerun_result: RerunResult,
) -> JiraTicketResult:
    """
    L1 resolved path — create Jira ticket with status DONE.
    Called when rerun succeeds after L1 fix.
    """
    pl = diagnostic.parsed_log
    summary = f"[AUTO-RESOLVED] {pl.error_code} in {pl.module} | Run {pl.run_id}"
    body_text = (
        f"Issue auto-resolved by Agentic AI L1 triage.\n\n"
        f"Error: {pl.error_code}\nModule: {pl.module}\nRun ID: {pl.run_id}\n"
        f"Bot Version: {pl.bot_version}\n\n"
        f"Fix Applied: {diagnostic.plain_english_fix}\n"
        f"Rerun Result: SUCCESS (exit code {rerun_result.exit_code})\n"
        f"Duration: {rerun_result.duration_secs}s\n"
        f"SOP: {diagnostic.sop_summary}\n"
        f"AI Confidence: {diagnostic.confidence_band}"
    )

    result = _create_ticket(
        summary=summary,
        description=_adf_text(body_text),
        priority="Low",
        status_transition="Done",
        error_hash=pl.error_hash,
        run_id=pl.run_id,
        labels=["auto-resolved", "l1-fix"],
    )
    result.action = "created_done"

    if result.success:
        _attach_log(result.ticket_key, pl.s3_path, pl.run_id)

    return result


def create_escalation_ticket(
    template: EscalationTemplate,
    diagnostic: DiagnosticResult,
) -> JiraTicketResult:
    """
    L2 escalation path — create Jira ticket with status OPEN.
    Called after user clicks Submit on the pre-filled template.
    """
    pl = diagnostic.parsed_log
    summary = (
        f"[{template.escalation_reason}] {template.error_summary} | "
        f"Run {pl.run_id} | {template.priority}"
    )

    result = _create_ticket(
        summary=summary,
        description=_adf_full(template),
        priority=template.priority,
        status_transition="To Do",
        error_hash=pl.error_hash,
        run_id=pl.run_id,
        labels=["l2-escalation", template.escalation_reason.lower()],
        link_to=template.link_to_ticket or None,
    )
    result.action = "created_open"

    if result.success:
        _attach_log(result.ticket_key, pl.s3_path, pl.run_id)

    return result


def add_comment(ticket_key: str, comment_text: str) -> JiraTicketResult:
    """Add a plain text comment to an existing Jira ticket."""
    try:
        resp = requests.post(
            f"{cfg.jira_base_url}/rest/api/3/issue/{ticket_key}/comment",
            auth=_auth(), headers=_headers(),
            json={"body": _adf_text(comment_text)},
            timeout=10,
        )
        resp.raise_for_status()
        logger.info(f"Comment added to {ticket_key}")
        return JiraTicketResult(
            success=True, ticket_key=ticket_key, action="comment_added"
        )
    except Exception as e:
        logger.error(f"Comment add failed on {ticket_key}: {e}")
        return JiraTicketResult(success=False, error=str(e))
