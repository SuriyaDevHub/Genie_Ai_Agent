"""GenieBot L1 Assistant - event-driven agentic triage pipeline."""

__version__ = "0.1.0"
