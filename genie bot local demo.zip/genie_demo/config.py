"""
config.py — Central config + JWT auth + OpenAI SDK clients (custom base_url)
============================================================================
Loads everything from .env. JWT auth replicates your existing OpenAM flow.
Two OpenAI SDK clients: one for the LLM endpoint, one for embeddings —
both use the same JWT injected via extra_headers.
"""

import os
import ssl
import threading
import time
import uuid
from datetime import datetime, timezone
from typing import Optional

import httpx
import requests
import truststore
from dotenv import load_dotenv
from openai import AsyncOpenAI, OpenAI

load_dotenv()

# ══════════════════════════════════════════════════════════════════════════
#  ENV CONFIG
# ══════════════════════════════════════════════════════════════════════════
# OpenAM / SSO
USERNAME    = os.getenv("OPENAM_USERNAME", "")
PASSWORD    = os.getenv("OPENAM_PASSWORD", "")
FQDN        = os.getenv("FQDN", "")
AUTH_URL    = os.getenv("AUTH_URL", f"https://{FQDN}/openam/json/authenticate")
JWT_VERSION = os.getenv("JWT_VERSION", "v2")
VERIFY_TLS  = os.getenv("VERIFY_TLS", "true").lower() == "true"
TOKEN_TTL   = 30

# LLM endpoint (OpenAI SDK, custom base_url)
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "")
LLM_MODEL    = os.getenv("LLM_MODEL", "")
LLM_TEMP     = float(os.getenv("LLM_TEMPERATURE", "0.0"))

# Embedding endpoint (same SDK, different base_url + model)
EMBED_BASE_URL = os.getenv("EMBED_BASE_URL", "")
EMBED_MODEL    = os.getenv("EMBED_MODEL", "text-embedding-3-small")

# Local data paths
JIRA_CSV     = os.getenv("JIRA_CSV", "./data/jira_tickets.csv")
SOP_CSV      = os.getenv("SOP_CSV", "./data/sop_data.csv")
TEMPLATE_CSV = os.getenv("TEMPLATE_CSV", "./data/l2_template.csv")
FAISS_DIR    = os.getenv("FAISS_DIR", "./faiss_index")

# Retrieval / dedup thresholds
SIM_THRESHOLD    = float(os.getenv("SIM_THRESHOLD", "0.55"))
HIGH_CONF_THRESH = float(os.getenv("HIGH_CONF_THRESH", "0.75"))
TOP_K            = int(os.getenv("TOP_K", "4"))
DEDUP_FUZZY_THRESH = float(os.getenv("DEDUP_FUZZY_THRESH", "0.82"))

_JWT_PATHS = {
    "v1": "/dsp/rest-sts/DSP_iB2B/iB2B_tokenTranslator",
    "v2": "/dsp/rest-sts/DSP_iB2B/iB2B_tokenTranslator_v2",
}


# ══════════════════════════════════════════════════════════════════════════
#  JWT AUTH  — exact replica of your existing code
# ══════════════════════════════════════════════════════════════════════════
def translate_sso_to_jwt(fqdn, sso_token, version="v2", verify_tls=True, timeout=30):
    if version not in _JWT_PATHS:
        raise ValueError("version must be 'v1' or 'v2'")
    resp = requests.post(
        f"https://{fqdn}{_JWT_PATHS[version]}",
        params={"_action": "translate"},
        headers={"Content-Type": "application/json", "Accept": "application/json"},
        json={
            "input_token_state":  {"token_type": "SSOTOKEN", "tokenId": sso_token},
            "output_token_state": {"token_type": "JWT"},
        },
        timeout=timeout, verify=verify_tls,
    )
    resp.raise_for_status()
    data = resp.json()
    if "issued_token" not in data:
        raise RuntimeError(f"Missing issued_token: {data}")
    return data["issued_token"]


def get_access_token():
    resp = requests.post(
        AUTH_URL,
        headers={
            "Accept-API-Version": "resource=2.0, protocol=1.0",
            "Content-Type":       "application/json",
            "X-OpenAM-Username":  USERNAME,
            "X-OpenAM-Password":  PASSWORD,
        },
        json={}, timeout=30, verify=VERIFY_TLS,
    )
    resp.raise_for_status()
    data     = resp.json()
    token_id = data.get("tokenId") or data.get("tokenid", "")
    return {"jwt": translate_sso_to_jwt(FQDN, token_id, version=JWT_VERSION, verify_tls=VERIFY_TLS)}


def get_token():
    return get_access_token().get("jwt", "")


def get_default_headers():
    return {
        "Content-Type":     "application/json",
        "x-correlation-id": str(uuid.uuid4()),
        "x-usersession-id": str(uuid.uuid4()),
    }


def get_extra_headers(jwt):
    """JWT goes here. Replace 'Authorization' if your header key differs."""
    return {"Authorization": f"Bearer {jwt}"}


def get_httpx_client():
    ctx = truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    return httpx.AsyncClient(http2=True, verify=ctx)


# ══════════════════════════════════════════════════════════════════════════
#  JWT MANAGER  — background refresh every 25s
# ══════════════════════════════════════════════════════════════════════════
class JWTManager:
    def __init__(self):
        self._token = ""; self._expires_at = 0.0
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._running = False
        self.last_refresh = "Never"; self.last_error = ""; self.refresh_count = 0

    @property
    def token(self):
        with self._lock: return self._token

    @property
    def is_valid(self):
        with self._lock: return bool(self._token) and time.time() < self._expires_at

    @property
    def seconds_remaining(self):
        with self._lock: return max(0, int(self._expires_at - time.time()))

    def start(self):
        self._fetch()
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):    self._running = False
    def refresh(self): self._fetch()

    def _loop(self):
        while self._running:
            time.sleep(max(TOKEN_TTL - 5, 5))
            self._fetch()

    def _fetch(self):
        try:
            tok = get_token()
            with self._lock:
                self._token = tok; self._expires_at = time.time() + TOKEN_TTL
                self.last_refresh = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
                self.last_error = ""; self.refresh_count += 1
        except Exception as e:
            with self._lock: self.last_error = str(e)


# ══════════════════════════════════════════════════════════════════════════
#  OPENAI SDK CLIENTS  — LLM (async) + Embeddings (sync)
# ══════════════════════════════════════════════════════════════════════════
_llm_client: Optional[AsyncOpenAI] = None


def get_llm_client():
    """Singleton AsyncOpenAI for the LLM endpoint."""
    global _llm_client
    if _llm_client is None:
        _llm_client = AsyncOpenAI(
            api_key="custom",
            http_client=get_httpx_client(),
            base_url=LLM_BASE_URL,
            default_headers=get_default_headers(),
        )
    return _llm_client


def get_embed_client(jwt):
    """Sync OpenAI client for the embedding endpoint. Recreated per call so JWT stays fresh."""
    return OpenAI(
        api_key="custom",
        base_url=EMBED_BASE_URL,
        default_headers={**get_default_headers(), **get_extra_headers(jwt)},
    )
