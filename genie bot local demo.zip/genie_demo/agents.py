"""
agents.py — Dedup agent (layered) + L1 triage + L2 template agents
==================================================================
Dedup agent uses three layers, in priority order:
  1. Signature/hash match  (error_code + module fingerprint)
  2. Error code + module exact match
  3. Fuzzy text similarity on summary/error message

L1 and L2 agents call your LLM endpoint (OpenAI SDK, custom base_url) with the
SOP context retrieved from FAISS.
"""

import asyncio
import json
from difflib import SequenceMatcher

import config
from data_layer import parse_error_fields, error_signature


# ══════════════════════════════════════════════════════════════════════════
#  DEDUP AGENT  — layered matching against local Jira tickets
# ══════════════════════════════════════════════════════════════════════════
OPEN_STATUSES = {"open", "to do", "in progress", "reopened", "new"}


def _similar(a: str, b: str) -> float:
    return SequenceMatcher(None, a.lower(), b.lower()).ratio()


def dedup_check(log_text: str, jira_tickets: list, user_id: str = "demo_user") -> dict:
    """
    Layered dedup. Returns:
      {
        "scenario": NEW_ISSUE | DUPLICATE_SAME_RUN | RECURRING_SAME_USER
                    | SAME_ISSUE_DIFF_USER | SIMILAR_ISSUE,
        "matched_ticket": <ticket dict or None>,
        "match_layer": "signature" | "code_module" | "fuzzy" | None,
        "match_score": float,
        "proceed": bool,      # True = continue to L1; False = blocked (already exists)
        "message": str,
      }
    """
    fields    = parse_error_fields(log_text)
    sig       = fields["signature"]
    code      = fields["error_code"]
    module    = fields["module"]
    run_id    = fields["run_id"]

    open_tickets = [t for t in jira_tickets
                    if t.get("status", "").lower() in OPEN_STATUSES]

    best = {"ticket": None, "layer": None, "score": 0.0}

    # ── Layer 1: signature/hash match ─────────────────────────────────────
    for t in open_tickets:
        if t.get("signature") and t["signature"] == sig:
            best = {"ticket": t, "layer": "signature", "score": 1.0}
            break

    # ── Layer 2: error_code + module exact match ──────────────────────────
    if not best["ticket"]:
        for t in open_tickets:
            if (t.get("error_code", "").lower() == code.lower()
                    and t.get("module", "").lower() == module.lower()
                    and code != "UnknownError"):
                best = {"ticket": t, "layer": "code_module", "score": 0.95}
                break

    # ── Layer 3: fuzzy text similarity ────────────────────────────────────
    if not best["ticket"]:
        probe = f"{code} {module}"
        for t in open_tickets:
            cand  = f"{t.get('error_code','')} {t.get('module','')} {t.get('summary','')}"
            score = _similar(probe, cand)
            if score > best["score"]:
                best = {"ticket": t, "layer": "fuzzy", "score": score}
        if best["score"] < config.DEDUP_FUZZY_THRESH:
            best = {"ticket": None, "layer": None, "score": best["score"]}

    # ── No match → NEW ISSUE, proceed to L1 ───────────────────────────────
    if not best["ticket"]:
        return {
            "scenario": "NEW_ISSUE", "matched_ticket": None,
            "match_layer": None, "match_score": round(best["score"], 3),
            "proceed": True,
            "message": "No existing ticket found. Proceeding with L1 diagnosis.",
        }

    # ── Match found → classify the dedup scenario ─────────────────────────
    t       = best["ticket"]
    t_run   = t.get("run_id", "")
    t_user  = t.get("reporter", "")
    t_key   = t.get("ticket_id", "")
    t_stat  = t.get("status", "")

    if t_run and run_id and t_run == run_id and t_user == user_id:
        scenario = "DUPLICATE_SAME_RUN"
        msg = f"You already reported this exact run. Ticket **{t_key}** is **{t_stat}** — no action needed."
    elif t_user == user_id:
        scenario = "RECURRING_SAME_USER"
        msg = f"This issue recurred for you. Ticket **{t_key}** (**{t_stat}**) is already being worked on."
    else:
        scenario = "SAME_ISSUE_DIFF_USER"
        msg = (f"Another user already reported this issue (**{t_key}**, **{t_stat}**). "
               f"You've been added as an affected user.")

    return {
        "scenario": scenario, "matched_ticket": t,
        "match_layer": best["layer"], "match_score": round(best["score"], 3),
        "proceed": False, "message": msg,
    }


# ══════════════════════════════════════════════════════════════════════════
#  LLM CALL  — your OpenAI SDK pattern
# ══════════════════════════════════════════════════════════════════════════
def _extract(message_content):
    """Replica of your extract_message_content."""
    if isinstance(message_content, str):
        return message_content
    if isinstance(message_content, list):
        parts = []
        for item in message_content:
            if isinstance(item, dict):
                if item.get("type") == "text" and item.get("text"):
                    parts.append(item["text"])
                elif item.get("type") == "output" and item.get("output"):
                    parts.append(item["output"])
        return "".join(parts)
    if hasattr(message_content, "content"):
        c = message_content.content
        if isinstance(c, str):  return c
        if isinstance(c, list): return _extract(c)
    return ""


async def _llm_async(messages, jwt, max_tokens=1000):
    extra_headers = config.get_extra_headers(jwt)
    client = config.get_llm_client()
    result = await client.chat.completions.create(
        model=config.LLM_MODEL,
        messages=messages,
        max_completion_tokens=max_tokens,
        extra_headers=extra_headers,
        user="",
        temperature=config.LLM_TEMP,
    )
    return _extract(result.choices[0].message.content)


def call_llm(messages, jwt, max_tokens=1000):
    return asyncio.run(_llm_async(messages, jwt, max_tokens))


def _parse_json(text):
    clean = text.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
    try:    return json.loads(clean)
    except: return {"_raw": text}


# ══════════════════════════════════════════════════════════════════════════
#  L1 TRIAGE AGENT
# ══════════════════════════════════════════════════════════════════════════
L1_SYSTEM = """You are a Genie Bot L1 support agent. Temperature=0.
Use ONLY the retrieved SOP context. Do not invent fixes.
plain_english_fix: numbered steps for a non-technical user, no jargon.
rerun_safe: true only if the SOP says so.
If no good SOP match, decision = ESCALATE.

Respond ONLY with valid JSON:
{
  "decision": "L1_FIX_AVAILABLE" or "ESCALATE",
  "confidence": "HIGH" or "MEDIUM" or "LOW",
  "root_cause": "plain English",
  "plain_english_fix": "numbered steps",
  "rerun_safe": true or false,
  "sop_reference": "SOP ref or null",
  "citations": ["SOP-001"]
}"""


def run_l1(log_text, retrieved, jwt):
    ctx = "\n\n".join(
        f"--- SOP {i} (score={s:.3f}, ref={d.metadata.get('sop_ref','?')}) ---\n{d.page_content}"
        for i, (d, s) in enumerate(retrieved, 1)
    )
    messages = [
        {"role": "system", "content": L1_SYSTEM},
        {"role": "user", "content":
            f"ERROR LOG:\n{log_text[:2000]}\n\nRETRIEVED SOPs:\n{ctx}\n\nJSON:"},
    ]
    return _parse_json(call_llm(messages, jwt, max_tokens=900))


# ══════════════════════════════════════════════════════════════════════════
#  L2 TEMPLATE AGENT
# ══════════════════════════════════════════════════════════════════════════
L2_SYSTEM = """You are a Genie Bot L2 escalation agent.
Pre-fill every template field from the error log, L1 diagnosis, and SOP context.
Respond ONLY with valid JSON — keys are the exact field names provided, values are the content."""


def run_l2(log_text, l1_result, template_fields, retrieved, jwt):
    fields_desc = "\n".join(
        f"- {f['field']}{' (mandatory)' if f['mandatory'] else ''}: {f['desc']}"
        for f in template_fields
    )
    ctx = "\n\n".join(
        f"SOP {i}: {d.page_content[:300]}"
        for i, (d, s) in enumerate(retrieved, 1)
    )
    messages = [
        {"role": "system", "content": L2_SYSTEM},
        {"role": "user", "content":
            f"ERROR LOG:\n{log_text[:1500]}\n\n"
            f"L1 DIAGNOSIS:\n{json.dumps(l1_result, indent=2)}\n\n"
            f"SOP CONTEXT:\n{ctx}\n\n"
            f"FIELDS TO FILL:\n{fields_desc}\n\nJSON:"},
    ]
    return _parse_json(call_llm(messages, jwt, max_tokens=1200))
