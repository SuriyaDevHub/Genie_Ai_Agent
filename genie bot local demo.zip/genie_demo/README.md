# Genie Bot AI Support Copilot — Local Demo

End-to-end demo running fully local: your embedding model + LLM model
(OpenAI SDK, custom base_url, JWT auth) + local FAISS + local Jira/SOP datasets.

## Architecture

```
                    ┌─────────────────────────────┐
   error log  ───►  │  DEDUP AGENT (layered)      │
                    │  vs local Jira tickets      │
                    └──────────┬──────────────────┘
                   duplicate?  │  new issue?
                  ┌────────────┘            └──────────┐
                  ▼                                    ▼
          show existing ticket            ┌────────────────────────┐
          (stop)                          │  L1: FAISS retrieve     │
                                          │      + LLM triage       │
                                          └──────────┬─────────────┘
                                       fix worked?   │  still broken?
                                      ┌──────────────┘        └────────┐
                                      ▼                                 ▼
                                  resolved              ┌──────────────────────┐
                                                        │  L2: LLM pre-fills    │
                                                        │  your template fields │
                                                        └──────────────────────┘
```

## Dedup Agent — 3 layers (priority order)

1. **Signature/hash** — `md5(error_code + module)` fingerprint match
2. **Code + module** — exact error_code AND module match
3. **Fuzzy text** — SequenceMatcher similarity above threshold (default 0.82)

Then classifies the scenario:
- `DUPLICATE_SAME_RUN` — same run_id + same reporter → no action
- `RECURRING_SAME_USER` — same reporter, different run → already being worked
- `SAME_ISSUE_DIFF_USER` — different reporter → added as affected user
- `NEW_ISSUE` — no match → proceed to L1

## Files

```
genie_demo/
├── config.py        # env + JWT auth + OpenAI SDK clients
├── data_layer.py    # CSV loaders + FAISS + embeddings
├── agents.py        # dedup agent + L1/L2 LLM agents
├── app.py           # Streamlit UI (4 stages)
├── data/
│   ├── jira_tickets.csv   # dedup source (swap with yours)
│   ├── sop_data.csv       # FAISS knowledge base
│   └── l2_template.csv    # escalation form fields
├── faiss_index/     # built on first run
├── .env.example
└── requirements.txt
```

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env
# fill in OPENAM_*, FQDN, AUTH_URL, LLM_BASE_URL, LLM_MODEL, EMBED_BASE_URL
streamlit run app.py
```

## Demo flow

1. Sidebar → Start JWT → Load Data (uses sample CSVs, or upload your own)
2. Paste a log → Diagnose
3. Dedup agent runs first:
   - Paste an error matching GBOT-1001 (NullReference + TradeDataExtractor)
     as reporter `alice` → see DUPLICATE detection
   - Paste a brand-new error → proceeds to L1
4. L1 shows resolution → click Escalate → L2 template pre-filled

## Swapping in your data

Replace the 3 CSVs in `data/` (or upload via the sidebar). Column names are
flexible — the loaders accept common variants (ticket_id/key/id,
summary/title, error_code/error, module/component, etc).

## Later: connect S3 + real Jira

- `data_layer.load_jira_tickets()` → swap for Jira REST API call
- log input → swap for S3 fetch by run_id
The agent logic and UI stay unchanged.
