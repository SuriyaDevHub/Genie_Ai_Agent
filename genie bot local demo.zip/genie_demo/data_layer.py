"""
data_layer.py — CSV loaders + local FAISS index (embeddings via your endpoint)
==============================================================================
Loads three local datasets:
  • Jira tickets  → used by the dedup agent (in-memory list of dicts)
  • SOP data      → embedded into FAISS for L1/L2 retrieval
  • L2 template   → field definitions for the escalation form

All column names are flexible — the loaders try several common header variants.
"""

import csv
import hashlib
import io
import re
from pathlib import Path
from typing import List, Optional

from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS

import config


# ══════════════════════════════════════════════════════════════════════════
#  COLUMN HELPERS
# ══════════════════════════════════════════════════════════════════════════
def _pick(row: dict, *names, default=""):
    """Return the first non-empty value among candidate column names."""
    for n in names:
        if n in row and str(row[n]).strip():
            return str(row[n]).strip()
    return default


def _read_csv(path_or_file) -> List[dict]:
    if hasattr(path_or_file, "read"):           # uploaded file object
        text = path_or_file.read().decode("utf-8", errors="replace")
    else:                                        # path string
        if not Path(path_or_file).exists():
            return []
        text = Path(path_or_file).read_text(encoding="utf-8", errors="replace")
    return list(csv.DictReader(io.StringIO(text)))


# ══════════════════════════════════════════════════════════════════════════
#  ERROR SIGNATURE  — used for dedup hash matching
# ══════════════════════════════════════════════════════════════════════════
def error_signature(error_code: str, module: str) -> str:
    """Stable fingerprint: same error+module → same hash across users/runs."""
    raw = f"{error_code.lower().strip()}|{module.lower().strip()}"
    return hashlib.md5(raw.encode()).hexdigest()[:12]


def parse_error_fields(log_text: str) -> dict:
    """Extract error_code, module, run_id from a raw log for dedup matching."""
    code = ""
    m = re.search(r"(System\.\w+Exception|\w+Exception|\w+Error)", log_text)
    if m: code = m.group(1)

    module = ""
    m = re.search(r"Module\s*[:=]\s*(\S+)", log_text, re.IGNORECASE)
    if m: module = m.group(1)
    if not module:
        m = re.search(r"at\s+\S+\.(\w+)\.(\w+)\(", log_text)
        if m: module = m.group(1)

    run_id = ""
    m = re.search(r"RUN_?ID\s*[:=]\s*(\S+)", log_text, re.IGNORECASE)
    if m: run_id = m.group(1)

    return {
        "error_code": code or "UnknownError",
        "module":     module or "UnknownModule",
        "run_id":     run_id,
        "signature":  error_signature(code or "UnknownError", module or "UnknownModule"),
    }


# ══════════════════════════════════════════════════════════════════════════
#  JIRA LOADER  — for dedup agent
# ══════════════════════════════════════════════════════════════════════════
def load_jira_tickets(path: Optional[str] = None) -> List[dict]:
    """
    Load Jira tickets into a list of normalized dicts.
    Flexible columns:
      ticket_id / key / id
      summary / title
      status / state
      error_code / error
      module / component
      reporter / user / assignee
      run_id
      root_cause, resolution (optional)
    """
    rows = _read_csv(path or config.JIRA_CSV)
    tickets = []
    for r in rows:
        code   = _pick(r, "error_code", "error", "Error Code", "ErrorCode")
        module = _pick(r, "module", "component", "Module", "Component")
        ticket = {
            "ticket_id": _pick(r, "ticket_id", "key", "id", "Ticket ID", "Key"),
            "summary":   _pick(r, "summary", "title", "Summary", "Title"),
            "status":    _pick(r, "status", "state", "Status", default="Open"),
            "error_code": code,
            "module":     module,
            "reporter":  _pick(r, "reporter", "user", "assignee", "Reporter", "User"),
            "run_id":    _pick(r, "run_id", "Run ID", "RunID"),
            "root_cause": _pick(r, "root_cause", "Root Cause"),
            "resolution": _pick(r, "resolution", "Resolution"),
            "signature": error_signature(code, module) if code else "",
        }
        tickets.append(ticket)
    return tickets


# ══════════════════════════════════════════════════════════════════════════
#  SOP LOADER  — for FAISS retrieval
# ══════════════════════════════════════════════════════════════════════════
def load_sop_documents(path: Optional[str] = None) -> List[Document]:
    rows = _read_csv(path or config.SOP_CSV)
    docs = []
    for i, r in enumerate(rows):
        sop_ref = _pick(r, "sop_ref", "sop_id", "SOP Ref", "id", default=f"SOP-{i+1}")
        module  = _pick(r, "module", "component", "Module")
        rerun   = _pick(r, "rerun_safe", "Rerun Safe", default="Unknown")
        # Build the searchable text from all available fields
        parts = []
        for label, *cands in [
            ("Error Pattern", "error_pattern", "error", "Error Pattern"),
            ("Root Cause",    "root_cause", "Root Cause"),
            ("Fix Steps",     "fix_steps", "resolution", "Fix Steps", "Resolution"),
            ("Module",        "module", "Module"),
        ]:
            val = _pick(r, *cands)
            if val:
                parts.append(f"{label}: {val}")
        if not parts:
            parts = [f"{k}: {v}" for k, v in r.items() if str(v).strip()]
        docs.append(Document(
            page_content="\n".join(parts),
            metadata={"sop_ref": sop_ref, "module": module,
                      "rerun_safe": rerun, "source": "sop"},
        ))
    return docs


# ══════════════════════════════════════════════════════════════════════════
#  TEMPLATE LOADER  — for L2 escalation form
# ══════════════════════════════════════════════════════════════════════════
def load_template(path: Optional[str] = None) -> List[dict]:
    rows = _read_csv(path or config.TEMPLATE_CSV)
    fields = []
    for r in rows:
        name = _pick(r, "field_name", "field", "Field Name", "Field")
        if not name:
            continue
        mand = _pick(r, "mandatory", "required", "Mandatory", "Required").lower()
        fields.append({
            "field":     name,
            "desc":      _pick(r, "description", "desc", "Description"),
            "example":   _pick(r, "example", "Example"),
            "mandatory": mand in ("yes", "true", "y", "1"),
        })
    return fields


# ══════════════════════════════════════════════════════════════════════════
#  EMBEDDINGS  — uses your endpoint via OpenAI SDK + JWT
# ══════════════════════════════════════════════════════════════════════════
class InternalEmbeddings:
    """LangChain-compatible embeddings backed by your internal endpoint."""

    def __init__(self, jwt_manager):
        self.jm = jwt_manager

    def _embed(self, texts):
        client = config.get_embed_client(self.jm.token)
        resp = client.embeddings.create(input=texts, model=config.EMBED_MODEL)
        return [d.embedding for d in resp.data]

    def embed_documents(self, texts):
        return self._embed(texts)

    def embed_query(self, text):
        return self._embed([text])[0]


# ══════════════════════════════════════════════════════════════════════════
#  FAISS BUILD / LOAD
# ══════════════════════════════════════════════════════════════════════════
def build_or_load_faiss(docs: List[Document], jwt_manager) -> FAISS:
    emb = InternalEmbeddings(jwt_manager)
    if Path(config.FAISS_DIR).exists():
        return FAISS.load_local(config.FAISS_DIR, emb,
                                allow_dangerous_deserialization=True)
    chunks = RecursiveCharacterTextSplitter(
        chunk_size=400, chunk_overlap=40
    ).split_documents(docs)
    vs = FAISS.from_documents(chunks, emb)
    vs.save_local(config.FAISS_DIR)
    return vs


def rebuild_faiss(docs: List[Document], jwt_manager) -> FAISS:
    import shutil
    if Path(config.FAISS_DIR).exists():
        shutil.rmtree(config.FAISS_DIR)
    return build_or_load_faiss(docs, jwt_manager)
