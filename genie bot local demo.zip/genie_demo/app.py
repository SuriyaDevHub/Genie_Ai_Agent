"""
app.py — Genie Bot AI Support Copilot (full local demo)
=======================================================
End-to-end flow:
  1. Load local Jira + SOP + template CSVs, build FAISS
  2. Paste/upload log → Diagnose
  3. DEDUP AGENT (layered, against local Jira) runs first:
       - If duplicate found  → show existing ticket, stop
       - If new              → proceed to L1
  4. L1 retrieval (FAISS) + LLM triage → show resolution
  5. Still broken → L2 template pre-filled by LLM → editable table → submit

Run:
  pip install streamlit langchain langchain-community faiss-cpu \
              openai httpx truststore requests python-dotenv
  streamlit run app.py
"""

import json

import streamlit as st

import config
import data_layer as dl
import agents


# ══════════════════════════════════════════════════════════════════════════
#  PAGE
# ══════════════════════════════════════════════════════════════════════════
st.set_page_config(page_title="Genie Bot AI Support", page_icon="🤖",
                   layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
  .block-container{padding-top:1.2rem}
  .stTextArea textarea{font-family:monospace;font-size:12px}
  .l1box{background:#f0fdf4;border-left:4px solid #16a34a;border-radius:6px;padding:18px 22px;margin:12px 0}
  .l2box{background:#eff6ff;border-left:4px solid #2563eb;border-radius:6px;padding:14px 18px;margin:12px 0}
  .dupbox{background:#fef2f2;border-left:4px solid #dc2626;border-radius:6px;padding:16px 20px;margin:12px 0}
  .newbox{background:#f0f9ff;border-left:4px solid #0284c7;border-radius:6px;padding:10px 16px;margin:8px 0;font-size:13px}
  .stepbox{background:#fafafa;border:1px solid #e5e7eb;border-radius:6px;padding:12px 16px;margin:8px 0}
  .tbl-hdr{background:#1e3a5f;color:white;padding:8px 12px;border-radius:6px 6px 0 0;font-weight:700;font-size:13px;display:grid;grid-template-columns:200px 1fr;gap:8px;margin-bottom:4px}
</style>
""", unsafe_allow_html=True)

# ── Session state ──────────────────────────────────────────────────────────
for k, v in {
    "jwt_manager": None, "jwt_started": False,
    "data_loaded": False,
    "jira_tickets": [], "sop_docs": [], "template_fields": [],
    "faiss_index": None,
    "stage": "idle",   # idle | dedup_blocked | l1_done | l2_done
    "log_text": "", "user_id": "demo_user",
    "dedup_result": None,
    "l1_result": None, "retrieved": None,
    "l2_result": None,
}.items():
    if k not in st.session_state:
        st.session_state[k] = v

if st.session_state.jwt_manager is None:
    st.session_state.jwt_manager = config.JWTManager()

jm = st.session_state.jwt_manager


# ══════════════════════════════════════════════════════════════════════════
#  SIDEBAR
# ══════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("## ⚙️ Setup")

    # Endpoints
    st.markdown("### 🔌 Endpoints")
    st.caption(f"**LLM:** `{config.LLM_BASE_URL or '⚠ not set'}` · `{config.LLM_MODEL or '—'}`")
    st.caption(f"**Embed:** `{config.EMBED_BASE_URL or '⚠ not set'}` · `{config.EMBED_MODEL}`")

    st.divider()

    # JWT
    st.markdown("### 🔐 JWT  `30s TTL`")
    if not st.session_state.jwt_started:
        if st.button("▶ Start JWT", type="primary", use_container_width=True):
            with st.spinner("OpenAM → SSO → JWT…"):
                try:
                    jm.start(); st.session_state.jwt_started = True; st.rerun()
                except Exception as e:
                    st.error(f"Auth failed: {e}")
    else:
        secs = jm.seconds_remaining
        icon = "🟢" if secs > 10 else "🟡"
        if jm.is_valid:
            st.success(f"{icon} Active — {secs}s left")
        else:
            st.error("🔴 Expired")
        c1, c2 = st.columns(2)
        if c1.button("🔄 Refresh", use_container_width=True): jm.refresh(); st.rerun()
        if c2.button("⏹ Stop", use_container_width=True):
            jm.stop(); st.session_state.jwt_started = False; st.rerun()
        st.caption(f"Last: {jm.last_refresh} | #{jm.refresh_count}")
        if jm.last_error: st.error(f"⚠ {jm.last_error[:90]}")

    st.divider()

    # Data loading
    st.markdown("### 📂 Local Datasets")
    st.caption("Jira (dedup) · SOP (FAISS) · L2 template")

    jira_up = st.file_uploader("Jira CSV", type=["csv"], key="jira_up")
    sop_up  = st.file_uploader("SOP CSV", type=["csv"], key="sop_up")
    tmpl_up = st.file_uploader("Template CSV", type=["csv"], key="tmpl_up")

    c1, c2 = st.columns(2)
    load_btn    = c1.button("Load Data", use_container_width=True,
                            disabled=not st.session_state.jwt_started)
    rebuild_btn = c2.button("Rebuild FAISS", use_container_width=True,
                            disabled=not st.session_state.jwt_started)

    if not st.session_state.jwt_started:
        st.caption("⚠ Start JWT first (embeddings need it)")

    if load_btn or rebuild_btn:
        with st.spinner("Loading CSVs…"):
            st.session_state.jira_tickets    = dl.load_jira_tickets(jira_up or None)
            st.session_state.sop_docs        = dl.load_sop_documents(sop_up or None)
            st.session_state.template_fields = dl.load_template(tmpl_up or None)
        with st.spinner("Embedding SOPs into FAISS…"):
            try:
                if rebuild_btn:
                    st.session_state.faiss_index = dl.rebuild_faiss(
                        st.session_state.sop_docs, jm)
                else:
                    st.session_state.faiss_index = dl.build_or_load_faiss(
                        st.session_state.sop_docs, jm)
                st.session_state.data_loaded = True
            except Exception as e:
                st.error(f"FAISS error: {e}")

        if st.session_state.data_loaded:
            st.success(
                f"✅ {len(st.session_state.jira_tickets)} Jira · "
                f"{st.session_state.faiss_index.index.ntotal} SOP vectors · "
                f"{len(st.session_state.template_fields)} template fields"
            )

    if st.session_state.data_loaded:
        st.caption(f"Jira tickets: {len(st.session_state.jira_tickets)}")

    st.divider()

    # Demo user (for dedup scenarios)
    st.markdown("### 👤 Demo User")
    st.session_state.user_id = st.text_input(
        "Reporter ID (for dedup matching)", value=st.session_state.user_id,
        help="Match against the 'reporter' column in your Jira CSV"
    )

    st.divider()
    if st.button("🔄 Start Over", use_container_width=True):
        for k in ["stage", "log_text", "dedup_result", "l1_result",
                  "retrieved", "l2_result"]:
            st.session_state[k] = None if k != "stage" and k != "log_text" else \
                ("idle" if k == "stage" else "")
        st.session_state.stage = "idle"
        st.rerun()
    st.caption("🔒 Genie Bot AI Copilot · Local Demo")


# ══════════════════════════════════════════════════════════════════════════
#  MAIN
# ══════════════════════════════════════════════════════════════════════════
st.title("🤖 Genie Bot AI Support Copilot")
st.caption("Local demo · Dedup agent (Jira) → L1 triage (FAISS+LLM) → L2 escalation template")


# ── STAGE: idle ───────────────────────────────────────────────────────────
if st.session_state.stage == "idle":

    if not st.session_state.data_loaded:
        st.info("👈 Start JWT and load your datasets from the sidebar first.")

    tab_paste, tab_upload = st.tabs(["📋 Paste Log", "📁 Upload File"])
    log_input = ""

    with tab_paste:
        log_input = st.text_area("Paste Genie Bot error log", height=220,
            placeholder=(
                "[2026-05-27 09:14:32 UTC] RUN_ID=GBT-20260527-0042 ENV=PROD\n"
                "[ERROR] Module: TradeDataExtractor | Exit: FAILED\n"
                "[ERROR] System.NullReferenceException: Object reference not set\n"
                "   at GeniBot.Core.DataExtractor.Execute() line 142"
            ), key="paste_input")

    with tab_upload:
        up = st.file_uploader("Upload .log / .txt", type=["log", "txt"], key="log_file")
        if up:
            log_input = up.read().decode("utf-8", errors="replace")
            st.text_area("Preview", value=log_input[:500], height=120, disabled=True)
        else:
            log_input = st.session_state.get("paste_input", "")

    ready = st.session_state.data_loaded and st.session_state.jwt_started and jm.is_valid
    if st.button("🔍 Diagnose Issue", type="primary",
                 use_container_width=True, disabled=not ready):
        if not log_input.strip():
            st.warning("Please paste or upload a log first.")
        else:
            st.session_state.log_text = log_input

            # ── DEDUP AGENT runs first ────────────────────────────────────
            with st.spinner("🔁 Dedup agent checking local Jira tickets…"):
                dedup = agents.dedup_check(
                    log_input, st.session_state.jira_tickets,
                    st.session_state.user_id)
                st.session_state.dedup_result = dedup

            if not dedup["proceed"]:
                st.session_state.stage = "dedup_blocked"
                st.rerun()

            # ── New issue → L1 ────────────────────────────────────────────
            with st.spinner("🔍 Retrieving SOPs + 🤖 L1 diagnosis…"):
                try:
                    retrieved = st.session_state.faiss_index.similarity_search_with_relevance_scores(
                        log_input[:1500], k=config.TOP_K)
                    l1 = agents.run_l1(log_input, retrieved, jm.token)
                    st.session_state.retrieved = retrieved
                    st.session_state.l1_result = l1
                    st.session_state.stage = "l1_done"
                    st.rerun()
                except Exception as e:
                    st.error(f"L1 failed: {e}")

    if not ready and st.session_state.data_loaded:
        st.caption("⚠ Start/refresh JWT in the sidebar")


# ── STAGE: dedup_blocked ──────────────────────────────────────────────────
elif st.session_state.stage == "dedup_blocked":
    d = st.session_state.dedup_result
    t = d["matched_ticket"]

    st.markdown('<div class="dupbox">', unsafe_allow_html=True)
    st.markdown(f"### 🔁 Duplicate Detected — {d['scenario'].replace('_',' ').title()}")
    st.markdown(d["message"])
    st.markdown("</div>", unsafe_allow_html=True)

    c1, c2, c3 = st.columns(3)
    c1.metric("Match Layer", d["match_layer"] or "—")
    c2.metric("Match Score", f"{d['match_score']:.2f}")
    c3.metric("Existing Ticket", t.get("ticket_id", "—"))

    st.markdown("#### Matched Ticket Details")
    st.json({
        "ticket_id":  t.get("ticket_id"),
        "summary":    t.get("summary"),
        "status":     t.get("status"),
        "error_code": t.get("error_code"),
        "module":     t.get("module"),
        "reporter":   t.get("reporter"),
        "run_id":     t.get("run_id"),
    })

    if st.button("← Diagnose another issue", use_container_width=True):
        st.session_state.stage = "idle"
        st.rerun()


# ── STAGE: l1_done ────────────────────────────────────────────────────────
elif st.session_state.stage == "l1_done":
    d  = st.session_state.dedup_result
    l1 = st.session_state.l1_result

    # Dedup banner (new issue)
    st.markdown(
        f'<div class="newbox">🆕 <b>Dedup:</b> {d["scenario"].replace("_"," ").title()} '
        f'· no existing ticket (best score {d["match_score"]:.2f})</div>',
        unsafe_allow_html=True)

    with st.expander("📋 Submitted log", expanded=False):
        st.code(st.session_state.log_text, language="text")

    st.markdown("---")

    if "_raw" in l1:
        st.markdown('<div class="l1box">', unsafe_allow_html=True)
        st.markdown("### ✅ L1 Resolution")
        st.markdown(l1["_raw"])
        st.markdown("</div>", unsafe_allow_html=True)
    else:
        conf = l1.get("confidence", "LOW")
        icon = {"HIGH":"🟢","MEDIUM":"🟡","LOW":"🔴"}.get(conf, "⚪")
        c1, c2, c3 = st.columns(3)
        c1.metric("Decision", "✅ L1 Fix" if l1.get("decision")=="L1_FIX_AVAILABLE" else "🔴 Escalate")
        c2.metric("Confidence", f"{icon} {conf}")
        c3.metric("SOP", l1.get("sop_reference") or "—")

        st.markdown('<div class="l1box">', unsafe_allow_html=True)
        st.markdown("### ✅ L1 Resolution")
        if l1.get("root_cause"):
            st.markdown("**Root Cause**"); st.info(l1["root_cause"])
        if l1.get("plain_english_fix"):
            st.markdown("**Fix Steps**")
            for line in l1["plain_english_fix"].split("\n"):
                if line.strip(): st.write(line)
        rerun = l1.get("rerun_safe", False)
        st.markdown(f"**Rerun Safe:** {'✅ Yes' if rerun else '❌ No'}")
        st.markdown("</div>", unsafe_allow_html=True)

    st.markdown("---")
    st.markdown('<div class="stepbox"><b>After trying the fix:</b></div>',
                unsafe_allow_html=True)
    c_ok, c_esc = st.columns(2)

    with c_ok:
        if st.button("✅ Fix Worked — Resolved", type="primary", use_container_width=True):
            st.success("✅ Issue resolved! (Jira agent would create a DONE ticket here.)")

    with c_esc:
        if st.button("🔴 Still Broken — Escalate to L2", use_container_width=True,
                     disabled=not jm.is_valid):
            with st.spinner("📋 Building L2 template…"):
                try:
                    l2 = agents.run_l2(
                        st.session_state.log_text, l1,
                        st.session_state.template_fields,
                        st.session_state.retrieved, jm.token)
                    st.session_state.l2_result = l2
                    st.session_state.stage = "l2_done"
                    st.rerun()
                except Exception as e:
                    st.error(f"L2 failed: {e}")

    with st.expander("🔍 Retrieved SOPs", expanded=False):
        for i, (doc, score) in enumerate(st.session_state.retrieved, 1):
            st.markdown(f"**{i}. {doc.metadata.get('sop_ref','?')}** — score {score:.3f}")
            st.text(doc.page_content[:300])


# ── STAGE: l2_done ────────────────────────────────────────────────────────
elif st.session_state.stage == "l2_done":
    l2 = st.session_state.l2_result

    with st.expander("📋 Submitted log", expanded=False):
        st.code(st.session_state.log_text, language="text")

    st.markdown('<div class="l2box">', unsafe_allow_html=True)
    st.markdown("### 📋 L2 Escalation Template — Pre-filled")
    st.caption("All fields editable · review · add comments · submit")
    st.markdown("</div>", unsafe_allow_html=True)

    filled = {}
    if "_raw" in l2:
        st.caption("LLM returned free text — edit below:")
        filled["content"] = st.text_area("L2 Content", value=l2["_raw"], height=320)
    else:
        st.markdown('<div class="tbl-hdr"><div>Field</div><div>Pre-filled Value (editable)</div></div>',
                    unsafe_allow_html=True)
        for f in st.session_state.template_fields:
            fname = f["field"]
            prefill = l2.get(fname, "")
            c_lbl, c_val = st.columns([2, 5])
            with c_lbl:
                st.markdown(f"**{fname}**" + (" 🔴" if f["mandatory"] else ""),
                            help=f["desc"] or None)
            with c_val:
                filled[fname] = st.text_area(fname, value=prefill, height=60,
                                             key=f"l2_{fname}", label_visibility="collapsed")

    st.markdown("---")
    extra = st.text_area("Additional Comments *(optional)*", height=70)
    if extra: filled["Additional Comments"] = extra

    c1, c2 = st.columns(2)
    if c1.button("🚀 Submit to L2", type="primary", use_container_width=True):
        st.success("✅ Submitted to L2 queue. (Jira agent would create the ticket here.)")
    if c2.button("📋 Export JSON", use_container_width=True):
        st.code(json.dumps(filled, indent=2), language="json")
